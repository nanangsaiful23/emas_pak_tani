<div class="content-wrapper">
  <?php echo $__env->make('layout' . '.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
            <h4><?php echo e($good->category->name); ?></h4>
              <div class="box-header" style="text-align: center;">
                <h1><?php echo e($good->name); ?></h1>
                <h4><?php echo e($good->code); ?></h4>
                <h5><?php if($good->brand != null): ?><?php echo e($good->brand->name); ?><?php endif; ?></h5>
              </div>
            <div class="box-body">
                <div style="text-align: center;">
                    <?php if($good->profilePicture() != null): ?><img src="<?php echo e(URL::to($role . '/image/' . $good->profilePicture()->location)); ?>" style="height: 200px;"><br><?php endif; ?>
                    <a href="<?php echo e(url($role . '/good/' . $good->id . '/photo/create')); ?>"><i class="fa fa-camera"></i><br>Tambah Foto</a><br>
                </div>
                <hr>
                <div class="panel-body">
                    <div class="row" style="text-align: center; background-color: #FFFAD7;">
                        <h4>Stock Barang</h4>
                        <div class="col-sm-12">
                            <div class="col-sm-4">
                                <h4>Total Loading</h4> 
                                <h3><?php echo e($good->good_loadings()->sum('real_quantity') . ' ' . $good->getPcsSellingPrice()->unit->code); ?></h3>
                            </div>
                            <div class="col-sm-4">
                                <h4>Total Terjual</h4>
                                <h3><?php echo e($good->good_transactions()->sum('real_quantity') . ' ' . $good->getPcsSellingPrice()->unit->code); ?></h3>
                            </div>
                            <div class="col-sm-4">
                                <h4>Sisa Barang</h4>
                                <h3><?php echo e($good->getStock() . ' ' . $good->getPcsSellingPrice()->unit->code); ?></h3>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <?php if(\Auth::user()->email == 'admin'): ?>
                        <div class="row" style="text-align: center; background-color: #A1C2F1;">
                            <h4>Harga Beli</h4>
                            <h3><?php if($good->getLastBuy() != null): ?> <?php echo e($good->getLastBuy()->good_loading->distributor->name . ' (' . $good->getLastBuy()->good_loading->note . ')'); ?> <?php endif; ?></h3>
                            <div class="col-sm-12">
                                <?php $__currentLoopData = $good->good_units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-4">
                                        <h3><?php echo e(showRupiah(roundMoney($unit->buy_price)) . ' /' . $unit->unit->name); ?></h3>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <hr>
                    <?php endif; ?>
                    <div class="row" style="text-align: center; background-color: #FDCEDF;">
                        <h4>Harga Jual</h4>
                        <div class="col-sm-12">
                            <?php $__currentLoopData = $good->good_units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-sm-4">
                                    <h3>
                                        <?php echo e(showRupiah(roundMoney($unit->selling_price)) . ' /' . $unit->unit->name); ?>

                                        <?php if(\Auth::user()->email == 'admin'): ?>
                                          <br>Untung: <?php echo e(showRupiah(roundMoney($unit->selling_price) - $unit->buy_price) . ' (' . calculateProfit($unit->buy_price, roundMoney($unit->selling_price))); ?>%)
                                        <?php endif; ?>
                                    </h3>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                      <a href="<?php echo e(url($role . '/good/' . $good->id . '/edit')); ?>" class="btn btn-info btn-flat btn-block form-control" target="_blank()">Ubah Data Barang</a>
                      <a href="<?php echo e(url($role . '/good/' . $good->id . '/transaction/2018-01-01/' . date('Y-m-d') . '/10')); ?>" class="btn btn-flat btn-block form-control back-pink white" target="_blank()">Lihat Riwayat Penjualan Barang</a>
                      <a href="<?php echo e(url($role . '/good/' . $good->id . '/loading/2018-01-01/' . date('Y-m-d') . '/10')); ?>" class="btn btn-success btn-flat btn-block form-control" target="_blank()">Lihat Riwayat Loading Barang</a>
                      <!-- <a href="<?php echo e(url($role . '/good/' . $good->id . '/price/10')); ?>" class="btn btn-danger btn-flat btn-block form-control" target="_blank()">Lihat Riwayat Pricing Barang</a> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    </section>
</div>

<style type="text/css">
    .select2-container--default .select2-selection--multiple .select2-selection__choice {
        background-color: rgb(60, 141, 188) !important;
    }
</style>
<?php $__env->startSection('js-addon'); ?>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\project_caca\emas_pak_tani\resources\views/layout/good/detail.blade.php ENDPATH**/ ?>