<div class="panel-body" style="color: black !important;">
    <div class="row">
        <?php $__currentLoopData = $good->good_units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e(Form::hidden('good_unit_ids[]', $unit->id)); ?>

            <div class="form-group">
                <?php echo Form::label('units[]', 'Satuan', array('class' => 'col-sm-12')); ?>

                <div class="col-sm-5">
                    <?php echo Form::text('units[]', $unit->unit->name, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                </div>
            </div>
            
            <div class="form-group">
                <?php echo Form::label('old_selling_prices[]', 'Harga Lama', array('class' => 'col-sm-12')); ?>

                <div class="col-sm-5">
                    <?php echo Form::text('old_selling_prices[]', showRupiah($unit->selling_price), array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                </div>
            </div>
            
            <div class="form-group">
                <?php echo Form::label('selling_prices[]', 'Harga Baru', array('class' => 'col-sm-12')); ?>

                <div class="col-sm-5">
                    <?php if($SubmitButtonText == 'View'): ?>
                        <?php echo Form::text('selling_prices[]', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                    <?php else: ?>
                        <?php echo Form::text('selling_prices[]', null, array('class' => 'form-control')); ?>

                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group">
                <?php echo Form::label('reason', 'Alasan', array('class' => 'col-sm-12')); ?>

                <div class="col-sm-5">
                    <?php if($SubmitButtonText == 'View'): ?>
                        <?php echo Form::text('reason', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                    <?php else: ?>
                        <?php echo Form::text('reason', null, array('class' => 'form-control')); ?>

                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group">
                <?php echo e(csrf_field()); ?>


                <div class="col-sm-5">
                    <hr>
                    <?php if($SubmitButtonText == 'Edit'): ?>
                        <?php echo Form::submit($SubmitButtonText, ['class' => 'btn form-control']); ?>

                    <?php elseif($SubmitButtonText == 'Tambah'): ?>
                        <?php echo Form::submit($SubmitButtonText, ['class' => 'btn form-control']); ?>

                    <?php endif; ?>
                </div>
            </div>
    </div>
</div>

<?php echo Form::close(); ?>


<?php $__env->startSection('js-addon'); ?>
<?php $__env->stopSection(); ?><?php /**PATH C:\project_caca\kuncen\resources\views/layout/good/form-price.blade.php ENDPATH**/ ?>