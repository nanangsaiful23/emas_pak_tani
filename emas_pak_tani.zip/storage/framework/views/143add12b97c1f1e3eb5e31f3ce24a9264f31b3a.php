<div class="panel-body" style="color: black !important;">
    <div class="row">
        <div class="form-group">
            <?php echo Form::label('code', 'Kode Akun', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('code', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <?php echo Form::text('code', null, array('class' => 'form-control')); ?>

                <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <?php echo Form::label('name', 'Nama Akun', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('name', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <?php echo Form::text('name', null, array('class' => 'form-control')); ?>

                <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <?php echo Form::label('type', 'Tipe Akun', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('type', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <select class="form-control select2" style="width: 100%;" name="type">
                        <div>
                            <option value="Debet">Debet</option>
                            <option value="Kredit">Kredit</option>
                        </div>
                    </select>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <?php echo Form::label('group', 'Grup Akun', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('group', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <select class="form-control select2" style="width: 100%;" name="group">
                        <div>
                            <option value="Neraca">Neraca</option>
                            <option value="Laba Rugi">Laba Rugi</option>
                        </div>
                    </select>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <?php echo Form::label('activa', 'Tipe Akun', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('activa', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <select class="form-control select2" style="width: 100%;" name="activa">
                        <div>
                            <option value="Aktiva">Aktiva</option>
                            <option value="Pasiva">Pasiva</option>
                        </div>
                    </select>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <?php echo Form::label('balance', 'Saldo Awal', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('balance', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <?php echo Form::text('balance', null, array('class' => 'form-control')); ?>

                <?php endif; ?>
            </div>
        </div>
        
        <div class="form-group">
            <?php echo e(csrf_field()); ?>


            <div class="col-sm-5">
                <hr>
                <?php if($SubmitButtonText == 'Edit'): ?>
                    <?php echo Form::submit($SubmitButtonText, ['class' => 'btn form-control']); ?>

                <?php elseif($SubmitButtonText == 'Tambah'): ?>
                    <?php echo Form::submit($SubmitButtonText, ['class' => 'btn form-control']); ?>

                <?php elseif($SubmitButtonText == 'View'): ?>
                    <a href="<?php echo e(url($role . '/account/' . $account->id . '/edit')); ?>" class="btn form-control">Ubah Data Akun</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php echo Form::close(); ?>


<?php $__env->startSection('js-addon'); ?>
<?php $__env->stopSection(); ?><?php /**PATH C:\project_caca\kuncen\resources\views/layout/account/form.blade.php ENDPATH**/ ?>