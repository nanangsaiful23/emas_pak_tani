<div class="panel-body" style="color: black !important;">
    <div class="row">
        <div class="form-group">
            <?php echo Form::label('file', 'File', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <input type="file" name="file">
            </div>
        </div>

        <div class="form-group">
            <?php echo Form::label('distributor_id', 'Distributor', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('distributor', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <input type="text" name="distributor_name" class="form-control" id="distributor_name">
                    <select class="form-control select2" style="width: 100%;" name="distributor_id" id="all_distributor">
                        <div>
                            <option value="null">Silahkan pilih distributor</option>
                            <?php $__currentLoopData = getDistributors(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $distributor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($distributor->id); ?>">
                                <?php echo e($distributor->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </select>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <?php echo Form::label('total_item_price', 'Total Harga', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php echo Form::text('total_item_price', null, array('class' => 'form-control')); ?>

            </div>
        </div>
        
        <div class="form-group">
            <?php echo e(csrf_field()); ?>


            <div class="col-sm-5">
                <hr>
                <?php if($SubmitButtonText == 'Edit'): ?>
                    <?php echo Form::submit($SubmitButtonText, ['class' => 'btn form-control']); ?>

                <?php elseif($SubmitButtonText == 'Tambah'): ?>
                    <?php echo Form::submit($SubmitButtonText, ['class' => 'btn form-control']); ?>

                <?php elseif($SubmitButtonText == 'View'): ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php echo Form::close(); ?>


<?php $__env->startSection('js-addon'); ?>
<?php $__env->stopSection(); ?><?php /**PATH C:\project_caca\kuncen\resources\views/layout/good-loading/form-excel.blade.php ENDPATH**/ ?>