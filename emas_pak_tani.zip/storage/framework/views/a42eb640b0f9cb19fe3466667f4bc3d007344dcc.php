<div class="content-wrapper">
  <?php echo $__env->make('layout' . '.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title"> Form Input Akun</h3>
          </div>

          <?php echo Form::model(old(),array('url' => route($role . '.account.store'), 'enctype'=>'multipart/form-data', 'method' => 'POST', 'class' => 'form-horizontal')); ?>

            <div class="box-body">
              <?php echo $__env->make('layout' . '.account.form', ['SubmitButtonText' => 'Tambah'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
          <?php echo Form::close(); ?>


        </div>
      </div>
    </div>
  </section>
</div><?php /**PATH C:\project_caca\kuncen\resources\views/layout/account/create.blade.php ENDPATH**/ ?>