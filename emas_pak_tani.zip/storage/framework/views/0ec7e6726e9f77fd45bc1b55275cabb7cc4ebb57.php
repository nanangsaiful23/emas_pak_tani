<?php if($errors->any()): ?>
	<section class="content" style="margin-bottom: -140px;">
    	<div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
					<div class="alert alert-danger" style="font-size: 15px; margin-bottom: -100px;">
				        <ul>
				            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                <?php echo e($error); ?><br>
				            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </ul>
				    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?><?php /**PATH C:\project_caca\emas_pak_tani\resources\views/layout/error.blade.php ENDPATH**/ ?>