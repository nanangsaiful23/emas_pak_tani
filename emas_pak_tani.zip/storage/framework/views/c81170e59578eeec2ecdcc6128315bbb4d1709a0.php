<div class="box-body" style="overflow-x:scroll; background-color: <?php echo e($color); ?>">
  <h3>Transaksi <?php echo e($name); ?></h3><br>
  <h4>Total transaksi transfer: <?php echo e(showRupiah($total_sum_price)); ?></h4>
  <h4>Total potongan: <?php echo e(showRupiah($total_discount_price)); ?></h4><br>
</div>
<div class="box-body" style="overflow-x:scroll; background-color: <?php echo e($color); ?>">
  <table id="example1" class="table table-bordered table-striped">
    <thead>
    <tr>
      <th>ID</th>
      <th>Waktu</th>
      <?php if($role == 'admin'): ?>
        <th>Kasir</th>
      <?php endif; ?>
      <th>Total Belanja</th>
      <th>Total Diskon</th>
      <th>Potongan Akhir</th>
      <th>Total Akhir</th>
      <th>Uang Dibayar</th>
      <th>Kembalian</th>
      <th class="center">Detail</th>
      <?php if($role == 'admin'): ?>
        <th class="center">Retur</th>
      <?php endif; ?>
    </tr>
    </thead>
    <tbody id="table-good">
      <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($transaction->id); ?></td>
          <td><?php echo e($transaction->created_at); ?></td>
          <?php if($role == 'admin'): ?>
            <td><?php echo e($transaction->actor()->name); ?></td>
          <?php endif; ?>
          <td><?php echo e(showRupiah($transaction->total_item_price)); ?></td>
          <td><?php echo e(showRupiah(checkNull($discount_price))); ?></td>
          <td><?php echo e(showRupiah($transaction->total_discount_price)); ?></td>
          <td><?php echo e(showRupiah($transaction->total_sum_price)); ?></td>
          <td><?php echo e(showRupiah($transaction->money_paid)); ?></td>
          <td><?php echo e(showRupiah($transaction->money_returned)); ?></td>
          <td class="center"><a href="<?php echo e(url($role . '/transaction/' . $transaction->id . '/detail')); ?>"><i class="fa fa-hand-o-right tosca" aria-hidden="true"></i></a></td>
          <?php if($role == 'admin'): ?>
          <td><button type="button" class="no-btn" data-toggle="modal" data-target="#modal-reverse-<?php echo e($transaction->id); ?>"><i class="fa fa-times red" aria-hidden="true"></i></button>

            <div class="modal modal-reverse fade" id="modal-reverse-<?php echo e($transaction->id); ?>">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span></button>
                      <h4 class="modal-title">Reverse transaksi</h4>
                  </div>
                  <div class="modal-body">
                      <p>Anda yakin ingin mereverse <?php echo e($transaction->id . ' total ' . showRupiah($transaction->total_sum_price)); ?>?</p>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-outline" onclick="event.preventDefault(); document.getElementById('reverse-form-<?php echo e($transaction->id); ?>').submit();">Reverse</button>
                  </div>
                </div>
              </div>
            </div>
            <form id="reverse-form-<?php echo e($transaction->id); ?>" action="<?php echo e(url($role . '/transaction/' . $transaction->id . '/reverse')); ?>" method="POST" style="display: none;">
              <?php echo e(csrf_field()); ?>

              <?php echo e(method_field('PUT')); ?>

            </form>
          </td>
          <?php endif; ?>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <div id="renderField">
      <?php if($pagination != 'all'): ?>
        <?php echo e($transactions->render()); ?>

      <?php endif; ?>
    </div>
  </table>
</div><?php /**PATH C:\project_caca\kuncen\resources\views/layout/transaction/all-form.blade.php ENDPATH**/ ?>