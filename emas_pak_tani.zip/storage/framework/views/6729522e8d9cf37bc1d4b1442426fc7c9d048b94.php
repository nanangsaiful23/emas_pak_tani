<div class="content-wrapper">
  <?php echo $__env->make('layout' . '.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title"> Form Input Loading</h3>
            <h5>Jika membuat barang baru (yang belum ada di sistem) silahkan buat barang baru di bagian paling bawah</h5>
            <h5>Jika mmebuat harga satuan baru, pilih barang dari daftar kemudian pilih satuannya</h5>
          </div>

          <?php echo Form::model(old(),array('url' => route($role . '.good-loading.store'), 'enctype'=>'multipart/form-data', 'method' => 'POST', 'class' => 'form-horizontal', 'id' => 'loading-form')); ?>

            <div class="box-body">
              <?php echo $__env->make('layout' . '.good-loading.form', ['SubmitButtonText' => 'Tambah'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
          <?php echo Form::close(); ?>


        </div>
      </div>
    </div>
  </section>
</div><?php /**PATH C:\project_caca\kuncen\resources\views/layout/good-loading/create.blade.php ENDPATH**/ ?>