<div class="content-wrapper">

  <?php echo $__env->make('layout' . '.alert-message', ['type' => $default['type'], 'data' => $default['data'], 'color' => $default['color']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title">Daftar transaksi</h3>
            <!-- <?php echo $__env->make('layout.search-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
          </div>
          <div class="box-body">
            <?php echo Form::label('show', 'Show', array('class' => 'col-sm-1 control-label')); ?>

           <div class="col-sm-1">
              <?php echo Form::select('show', getPaginations(), $pagination, ['class' => 'form-control', 'style'=>'width: 100%', 'id' => 'show', 'onchange' => 'advanceSearch()']); ?>

            </div>
            <?php echo Form::label('user_id', 'PIC', array('class' => 'col-sm-1 control-label')); ?>

           <div class="col-sm-2">
              <?php echo Form::select('user_id', getUsers(), $role_user . '/' . $role_id, ['class' => 'form-control select2', 'style'=>'width: 100%', 'id' => 'user_id', 'onchange' => 'advanceSearch()']); ?>

            </div>
            <?php echo Form::label('start_date', 'Tanggal Awal', array('class' => 'col-sm-1 control-label')); ?>

            <div class="col-sm-2">
              <div class="input-group date">
                <input type="text" class="form-control pull-right" id="datepicker" name="start_date" value="<?php echo e($start_date); ?>" onchange="changeDate()">
              </div>
            </div>
            <?php echo Form::label('end_date', 'Tanggal Akhir', array('class' => 'col-sm-1 control-label')); ?>

            <div class="col-sm-2">
              <div class="input-group date">
                <input type="text" class="form-control pull-right" id="datepicker2" name="end_date" value="<?php echo e($end_date); ?>" onchange="changeDate()">
              </div>
            </div>
          </div>
          <div class="box-body" style="overflow-x:scroll; background-color: #E5F9DB">
            <h3>Transaksi</h3><br>
            <h4>Total transaksi: <?php echo e(showRupiah($transactions->sum('total_sum_price'))); ?></h4>
            <h4>Total potongan: <?php echo e(showRupiah($transactions->sum('total_discount_price'))); ?></h4><br>
          </div>
          <div class="box-body" style="overflow-x:scroll; background-color: #E5F9DB">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>Tipe</th>
                <th>Waktu</th>
                <?php if(\Auth::user()->email == 'admin'): ?>
                  <th>Kasir</th>
                <?php endif; ?>
                <th>Total Belanja</th>
                <th>Total Diskon</th>
                <th>Potongan Akhir</th>
                <th>Total Akhir</th>
                <th>Uang Dibayar</th>
                <th>Kembalian</th>
                <th class="center">Detail</th>
              </tr>
              </thead>
              <tbody id="table-good">
                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($transaction->type_name()->code . ' - ' . $transaction->type_name()->name); ?></td>
                    <td><?php echo e($transaction->created_at); ?></td>
                    <?php if(\Auth::user()->email == 'admin'): ?>
                      <td><?php echo e($transaction->actor()->name); ?></td>
                    <?php endif; ?>
                    <td><?php echo e(showRupiah($transaction->total_item_price)); ?></td>
                    <td><?php echo e(showRupiah(checkNull($transaction->details->sum('discount_price')))); ?></td>
                    <td><?php echo e(showRupiah($transaction->total_discount_price)); ?></td>
                    <td><?php echo e(showRupiah($transaction->total_sum_price)); ?></td>
                    <td><?php echo e(showRupiah($transaction->money_paid)); ?></td>
                    <td><?php echo e(showRupiah($transaction->money_returned)); ?></td>
                    <td class="center"><a href="<?php echo e(url($role . '/transaction/' . $transaction->id . '/detail')); ?>"><i class="fa fa-hand-o-right tosca" aria-hidden="true"></i></a></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <div id="renderField">
                <?php if($pagination != 'all'): ?>
                  <?php echo e($transactions->render()); ?>

                <?php endif; ?>
              </div>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<?php $__env->startSection('js-addon'); ?>
  <script type="text/javascript">
    $(document).ready(function(){
      $('.select2').select2();
      $('#datepicker').datepicker({
        autoclose: true,
        format: 'yyyy-mm-dd'
      })

      $('#datepicker2').datepicker({
        autoclose: true,
        format: 'yyyy-mm-dd'
      })

      $("#search-input").keyup( function(e){
        if(e.keyCode == 13)
        {
          ajaxFunction();
        }
      });

      $("#search-btn").click(function(){
          ajaxFunction();
      });
    });

    function changeDate()
    {
      window.location = window.location.origin + '/<?php echo e($role); ?>/internal-transaction/<?php echo e($role_user); ?>/<?php echo e($role_id); ?>/' + $("#datepicker").val() + '/' + $("#datepicker2").val() + '/<?php echo e($pagination); ?>';
    }

    function advanceSearch()
    {
      var show        = $('#show').val();
      var user_id     = $('#user_id').val();
      window.location = window.location.origin + '/<?php echo e($role); ?>/internal-transaction/' + user_id + '/<?php echo e($start_date); ?>/<?php echo e($end_date); ?>/' + show;
    }
  </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\project_caca\kuncen\resources\views/layout/internal-transaction/all.blade.php ENDPATH**/ ?>