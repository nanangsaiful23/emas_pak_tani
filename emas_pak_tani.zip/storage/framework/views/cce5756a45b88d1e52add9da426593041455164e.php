<div class="content-wrapper">

  <?php echo $__env->make('layout' . '.alert-message', ['type' => $default['type'], 'data' => $default['data'], 'color' => $default['color']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title">List Loading</h3>
            <!-- <?php echo $__env->make('layout.search-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
          </div>
          <div class="box-body">
            <?php echo Form::label('show', 'Show', array('class' => 'col-sm-1 control-label')); ?>

           <div class="col-sm-1">
              <?php echo Form::select('show', getPaginations(), $pagination, ['class' => 'form-control', 'style'=>'width: 100%', 'id' => 'show', 'onchange' => 'advanceSearch()']); ?>

            </div>
            <?php echo Form::label('start_date', 'Tanggal Awal', array('class' => 'col-sm-1 control-label')); ?>

            <div class="col-sm-2">
              <div class="input-group date">
                <input type="text" class="form-control pull-right" id="datepicker" name="start_date" value="<?php echo e($start_date); ?>" onchange="changeDate()">
              </div>
            </div>
            <?php echo Form::label('end_date', 'Tanggal Akhir', array('class' => 'col-sm-1 control-label')); ?>

            <div class="col-sm-2">
              <div class="input-group date">
                <input type="text" class="form-control pull-right" id="datepicker2" name="end_date" value="<?php echo e($end_date); ?>" onchange="changeDate()">
              </div>
            </div>
            <?php echo Form::label('distributor', 'Distributor', array('class' => 'col-sm-1 control-label')); ?>

            <div class="col-sm-3">
              <?php echo Form::select('distributor', getDistributorLoading($distributor_id, $start_date, $end_date), $distributor_id, ['class' => 'form-control select2', 'style'=>'width: 100%', 'id' => 'distributor', 'onchange' => 'advanceSearch()']); ?>

            </div>
          </div>
          <div class="box-body" style="overflow-x:scroll">
            <h4>Total loading: <?php echo e(showRupiah($good_loadings->sum('total_item_price'))); ?></h4><br>
          </div>
          <div class="box-body" style="overflow-x:scroll">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
              <tr>
                <?php if(\Auth::user()->email == 'admin'): ?>
                  <th>Created at</th>
                <?php endif; ?>
                <th>Tanggal</th>
                <th>Nama distributor</th>
                <th>Total Loading</th>
                <th>Catatan</th>
                <th>User</th>
                <th class="center">Detail</th>
              </tr>
              </thead>
              <tbody id="table-good">
                <?php $__currentLoopData = $good_loadings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $good_loading): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <?php if(\Auth::user()->email == 'admin'): ?>
                      <td><?php echo e($good_loading->created_at); ?></td>
                    <?php endif; ?>
                    <td><?php echo e(displayDate($good_loading->loading_date)); ?></td>
                    <td><?php echo e($good_loading->distributor->name); ?></td>
                    <td><?php echo e(showRupiah($good_loading->total_item_price)); ?></td>
                    <td><?php echo e($good_loading->note); ?></td>
                    <td><?php echo e($good_loading->actor()->name); ?></td>
                    <td class="center"><a href="<?php echo e(url($role . '/good-loading/' . $good_loading->id . '/detail')); ?>"><i class="fa fa-hand-o-right tosca" aria-hidden="true"></i></a></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <div id="renderField">
                <?php if($pagination != 'all'): ?>
                  <?php echo e($good_loadings->render()); ?>

                <?php endif; ?>
              </div>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<?php $__env->startSection('js-addon'); ?>
  <script type="text/javascript">
    $(document).ready(function(){
        $('.select2').select2();
      $('#datepicker').datepicker({
        autoclose: true,
        format: 'yyyy-mm-dd'
      })

      $('#datepicker2').datepicker({
        autoclose: true,
        format: 'yyyy-mm-dd'
      })

      $("#search-input").keyup( function(e){
        if(e.keyCode == 13)
        {
          ajaxFunction();
        }
      });

      $("#search-btn").click(function(){
          ajaxFunction();
      });
    });

    function changeDate()
    {
        var distributor = $('#distributor').val();
      window.location = window.location.origin + '/<?php echo e($role); ?>/good-loading/' + $("#datepicker").val() + '/' + $("#datepicker2").val() +'/'+distributor +'/<?php echo e($pagination); ?>';
    }

    function advanceSearch()
    {
      var show        = $('#show').val();
      var distributor = $('#distributor').val();
      window.location = window.location.origin + '/<?php echo e($role); ?>/good-loading/<?php echo e($start_date); ?>/<?php echo e($end_date); ?>/'+distributor+'/' + show;
    }
  </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\project_caca\kuncen\resources\views/layout/good-loading/all.blade.php ENDPATH**/ ?>