<div class="content-wrapper">

  <?php echo $__env->make('layout' . '.alert-message', ['type' => $default['type'], 'data' => $default['data'], 'color' => $default['color']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title"><?php echo e($default['page_name'] . ' ' . $good->name); ?></h3>
            <!-- <?php echo $__env->make('layout.search-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
          </div>
          <div class="box-body">
            <?php echo Form::label('show', 'Show', array('class' => 'col-sm-1 control-label')); ?>

           <div class="col-sm-1">
              <?php echo Form::select('show', getPaginations(), $pagination, ['class' => 'form-control', 'style'=>'width: 100%', 'id' => 'show', 'onchange' => 'advanceSearch()']); ?>

            </div>
            <?php echo Form::label('start_date', 'Tanggal Awal', array('class' => 'col-sm-1 control-label')); ?>

            <div class="col-sm-2">
              <div class="input-group date">
                <input type="text" class="form-control pull-right" id="datepicker" name="start_date" value="<?php echo e($start_date); ?>" onchange="changeDate()">
              </div>
            </div>
            <?php echo Form::label('end_date', 'Tanggal Akhir', array('class' => 'col-sm-1 control-label')); ?>

            <div class="col-sm-2">
              <div class="input-group date">
                <input type="text" class="form-control pull-right" id="datepicker2" name="end_date" value="<?php echo e($end_date); ?>" onchange="changeDate()">
              </div>
            </div>
          </div>
          <div class="box-body" style="overflow-x:scroll">
            <h4>Total penjualan: <?php echo e($transactions->sum('real_quantity')); ?></h4><br>
          </div>
          <div class="box-body" style="overflow-x:scroll">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>Created at</th>
                <th>ID</th>
                <th>Tipe</th>
                <th>PIC</th>
                <th>Jumlah</th>
                <th>Unit</th>
                <th>Jumlah Real</th>
                <th>Stock Terakhir</th>
                <?php if(\Auth::user()->email == 'admin'): ?>
                  <th>Harga Beli</th>
                <?php endif; ?>
                <th>Harga Jual</th>
                <th>Harga Jual Total</th>
                <th>Total Diskon</th>
                <th>Harga Jual Setelah Diskon</th>
                <th>Total Akhir</th>
              </tr>
              </thead>
              <tbody id="table-good">
                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($transaction->created_at); ?></td>
                    <td><a href="<?php echo e(url($role . '/transaction/' . $transaction->transaction->id . '/detail')); ?>" class="btn"><?php echo e($transaction->transaction->id); ?></a></td>
                    <td><?php echo e($transaction->type); ?></td>
                    <td><?php echo e($transaction->transaction->actor()->name); ?></td>
                    <td><?php echo e($transaction->quantity); ?></td>
                    <td><?php echo e($transaction->good_unit->unit->name); ?></td>
                    <td><?php echo e($transaction->real_quantity); ?></td>
                    <td><?php echo e($transaction->last_stock); ?></td>
                    <?php if(\Auth::user()->email == 'admin'): ?>
                      <td style="text-align: right;"><?php echo e(showRupiah($transaction->buy_price)); ?></td>
                    <?php endif; ?>
                    <td style="text-align: right;"><?php echo e(showRupiah($transaction->selling_price)); ?></td>
                    <td style="text-align: right;"><?php echo e(showRupiah($transaction->quantity * $transaction->selling_price)); ?></td>
                    <td style="text-align: right;"><?php echo e(showRupiah($transaction->discount_price)); ?></td>
                    <td style="text-align: right;"><?php echo e(showRupiah($transaction->sum_price / $transaction->quantity)); ?></td>
                    <td style="text-align: right;"><?php echo e(showRupiah($transaction->sum_price)); ?></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <div id="renderField">
                <?php if($pagination != 'all'): ?>
                  <?php echo e($transactions->render()); ?>

                <?php endif; ?>
              </div>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<?php $__env->startSection('js-addon'); ?>
  <script type="text/javascript">
    $(document).ready(function(){
      $('#datepicker').datepicker({
        autoclose: true,
        format: 'yyyy-mm-dd'
      })

      $('#datepicker2').datepicker({
        autoclose: true,
        format: 'yyyy-mm-dd'
      })

      $("#search-input").keyup( function(e){
        if(e.keyCode == 13)
        {
          ajaxFunction();
        }
      });

      $("#search-btn").click(function(){
          ajaxFunction();
      });
    });

    function changeDate()
    {
        var distributor = $('#distributor').val();
      window.location = window.location.origin + '/<?php echo e($role); ?>/good/<?php echo e($good->id); ?>/transaction/' + $("#datepicker").val() + '/' + $("#datepicker2").val() +'/<?php echo e($pagination); ?>';
    }

    function advanceSearch()
    {
      var show        = $('#show').val();
      var distributor = $('#distributor').val();
      window.location = window.location.origin + '/<?php echo e($role); ?>/good/<?php echo e($good->id); ?>/transaction/<?php echo e($start_date); ?>/<?php echo e($end_date); ?>/' + show;
    }
  </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\project_caca\kuncen\resources\views/layout/Good/transaction.blade.php ENDPATH**/ ?>