<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <link rel="icon" type="image/gif" href="<?php echo e(asset('assets/icon/education.png')); ?>" />
        <title><?php if(isset($default['page_name'])): ?><?php echo e($default['page_name']); ?><?php endif; ?></title>
        <!-- Tell the browser to be responsive to screen width -->
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <!-- Bootstrap 3.3.7 -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/bower_components/font-awesome/css/font-awesome.min.css')); ?>">
        <!-- Ionicons -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/bower_components/Ionicons/css/ionicons.min.css')); ?>">
        <!-- Theme style -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/dist/css/AdminLTE.min.css')); ?>">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cookie&family=Cormorant&family=Dosis&family=Noto+Sans+Arabic&family=Crimson+Text&family=Dancing+Script&family=Inter:wght@300;400;500;600">
    </head>

    <style type="text/css">
      body, span, h1, h2, h3
      {
        font-family: inter !important;
        font-weight: 300;
        color: black;
/*        color: #FF7B54;*/
      }

      table, th, td
      {
        border: solid black 2px !important;
      }

      .btn-input
      {
        height: 60px !important;
        margin: 5px;
        font-size: 20px;
      }
    </style>

    <body class="hold-transition sidebar-mini" style="background-color: white !important">
        <div class="wrapper">
            <section class="content">
              <div class="row">
                <div class="col-xs-12">
                  <div class="box">
                    <div class="box-header" style="text-align: center;">
                      <h1 class="box-title" style="font-size: 30px !important;">CARI BARANG</h1>
                    </div>
                    <div class="box-body" style="overflow-x:scroll; color: black !important">
                      <div class="col-sm-12">
                        <div class="btn col-sm-6" style="border: solid black 2px; font-size: 20px;" onclick="changeView('photo')">Tampilan foto</div>
                        <div class="btn col-sm-6" style="border: solid black 2px; font-size: 20px;" onclick="changeView('list')">Tampilan list</div>
                      </div>
                      <div class="col-sm-12" style="margin-top: 20px"> 
                        <div class="input-group">
                          <input type="text" name="q" class="form-control" placeholder="Search..." id="search-input" value="<?php echo e($query); ?>" style="height: 50px; font-size: 30px; border: solid black 2px;">
                          <span class="input-group-btn">
                            <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search" style="font-size: 30px"></i>
                            </button>
                          </span>
                          <span class="input-group-btn">
                            <div class="loader" style="display: none;"></div>
                          </span>
                        </div>
                      </div>
                      <div class="col-sm-12">
                        <div class="col-sm-1 btn btn-input btn-warning" onclick="changeInput('bed cover')">Bed Cover</div>
                        <div class="col-sm-1 btn btn-input btn-warning" onclick="changeInput('beras')">Beras</div>
                        <div class="col-sm-1 btn btn-input btn-warning" onclick="changeInput('ember')">Ember</div>
                        <div class="col-sm-1 btn btn-input btn-warning" onclick="changeInput('gelas')">Gelas</div>
                        <div class="col-sm-1 btn btn-input btn-warning" onclick="changeInput('gula')">Gula</div>
                        <div class="col-sm-1 btn btn-input btn-warning" onclick="changeInput('kompor')">Kompor</div>
                        <div class="col-sm-1 btn btn-input btn-warning" onclick="changeInput('magic com')">Magic Com</div>
                        <div class="col-sm-1 btn btn-input btn-warning" onclick="changeInput('piring')">Piring</div>
                        <div class="col-sm-1 btn btn-input btn-warning" onclick="changeInput('sprei')">Sprei</div>
                        <div class="col-sm-1 btn btn-input btn-warning" onclick="changeInput('tikar')">Tikar</div>
                      </div>
                      <div class="col-sm-12" id="photo-div"> 
                        <?php $__currentLoopData = $goods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $good): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="col-sm-4" style="text-align: center; border: black solid 2px;"> 
                            <?php $__currentLoopData = $good->good_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <img src="<?php echo e(URL::to('image/' . $photo->location)); ?>" style="width: 200px; display: block; margin: auto;">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <h3><?php echo e($good->code); ?></h3>
                            <h3><?php echo e($good->name); ?></h3>
                            <?php $__currentLoopData = $good->good_units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($unit->unit != null): ?>
                                <h3><?php echo e(showRupiah($unit->selling_price) . '/' . $unit->unit->name); ?></h3>
                              <?php else: ?>
                                <?php echo e($unit); ?>

                              <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($good->getPcsSellingPrice() == null): ?>
                              <h3>0</h3>
                            <?php else: ?>
                              <h3><?php echo e($good->getStock() . ' ' . $good->getPcsSellingPrice()->unit->code); ?></h3>
                            <?php endif; ?>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                      <?php $i = 0 ?>
                      <div class="col-sm-12" id="table-div" style="margin-top: 20px">
                        <table class="table table-bordered table-striped" style="font-size: 28px;">
                          <thead>
                            <tr>
                              <th>Kode</th>
                              <th>Nama</th>
                              <th>Harga Jual</th>
                              <th>Stock</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php $__currentLoopData = $goods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $good): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr <?php if($i % 2 == 0): ?> style="background-color: #FFD0D0" <?php endif; ?>>
                                <td><?php echo e($good->code); ?></td>
                                <td><?php echo e($good->name); ?></td>
                                <td>
                                  <?php $__currentLoopData = $good->good_units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($unit->unit != null): ?>
                                <h3><?php echo e(showRupiah($unit->selling_price) . '/' . $unit->unit->name); ?></h3>
                              <?php else: ?>
                                <?php echo e($unit); ?>

                              <?php endif; ?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <?php if($good->getPcsSellingPrice() == null): ?>
                                  <td>0</td>
                                <?php else: ?>
                                  <td>
                                    <?php echo e($good->getStock() . ' ' . $good->getPcsSellingPrice()->unit->code); ?><br>
                                    (<?php echo e(($good->getStock() * $good->getPcsSellingPrice()->unit->quantity) . ' ' . $good->getPcsSellingPrice()->unit->base); ?>)
                                  </td>
                                <?php endif; ?>
                              </tr>
                              <?php $i++ ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
    </body>

    <script src="<?php echo e(asset('assets/bower_components/jquery/dist/jquery.min.js')); ?>"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="<?php echo e(asset('assets/bower_components/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.7 -->
    <script src="<?php echo e(asset('assets/bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <!-- Select2 -->
    <script src="<?php echo e(asset('assets/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>

    <script type="text/javascript">
      $(document).ready(function(){
          $('#photo-div').hide();
          $('.select2').select2();
          $("#search-input").keyup( function(e){
            if(e.keyCode == 13)
            {
              search();
            }
          });

          $("#search-btn").click(function(){
              search();
          });
      });
      function search()
      {
        window.location = window.location.origin + '/search/' + $('#search-input').val();
      }

      function changeInput(keyword)
      {
        window.location = window.location.origin + '/search/' + keyword;
      }

      function changeView(view)
      {
        if(view == 'photo')
        {
          $('#photo-div').show();
          $('#table-div').hide();
        }
        else
        {
          $('#photo-div').hide();
          $('#table-div').show();
        }
      }
    </script>
</html><?php /**PATH C:\project_caca\kuncen\resources\views/layout/good-search.blade.php ENDPATH**/ ?>