<div class="panel-body" style="color: black !important;">
    <div class="row">
        <div class="form-group">
            <?php echo Form::label('type', 'Tipe Transaksi', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('type', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <select class="form-control select2" style="width: 100%;" name="type" onchange="showother_payment()" id="type">
                        <div>
                            <option value="box_transaction">Penjualan Kardus</option>
                            <option value="piutang_transaction">Pembayaran Piutang</option>
                            <option value="pulsa_transaction">Penjualan Pulsa/Token Listrik</option>
                        </div>
                    </select>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group" id='member'>
            <?php echo Form::label('member_id', 'Member', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('member', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <select class="form-control select2" style="width: 100%;" name="member_id" id="all_member">
                        <div>
                            <option value="null">Non Member</option>
                            <?php $__currentLoopData = getMembers(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($member->id); ?>">
                                <?php echo e($member->name . ' (' . $member->address . ')'); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </select>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group" id='payment'>
            <?php echo Form::label('payment', 'Jenis Pembayaran', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('payment', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <select class="form-control select2" style="width: 100%;" name="payment">
                        <div>
                            <option value="cash">Tunai/Cash</option>
                            <option value="transfer">Transfer</option>
                        </div>
                    </select>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group" id="buy_price_div">
            <?php echo Form::label('buy_price', 'Harga Beli Pulsa/Token', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('buy_price', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <?php echo Form::text('buy_price', null, array('class' => 'form-control', 'onkeyup' => 'formatNumber("buy_price")')); ?>

                <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <?php echo Form::label('money', 'Harga Jual/Nominal', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('money', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <?php echo Form::text('money', null, array('class' => 'form-control', 'onkeyup' => 'formatNumber("money")')); ?>

                <?php endif; ?>
            </div>
        </div>

        <div class="form-group" id="no_token">
            <?php echo Form::label('no_token', 'No Token Listrik/Nomor HP', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('no_token', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <?php echo Form::text('no_token', null, array('class' => 'form-control')); ?>

                <?php endif; ?>
            </div>
        </div>
        
        <div class="form-group">
            <?php echo e(csrf_field()); ?>


            <div class="col-sm-5">
                <hr>
                <?php if($SubmitButtonText == 'Edit'): ?>
                    <?php echo Form::submit($SubmitButtonText, ['class' => 'btn form-control']); ?>

                <?php elseif($SubmitButtonText == 'Tambah'): ?>
                    <?php echo Form::submit($SubmitButtonText, ['class' => 'btn form-control']); ?>

                <?php elseif($SubmitButtonText == 'View'): ?>
                    <a href="<?php echo e(url($role . '/other-transaction/' . $other_transaction->id . '/edit')); ?>" class="btn form-control">Ubah Data Transaksi Lain</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php echo Form::close(); ?>


<?php $__env->startSection('js-addon'); ?>
    <script type="text/javascript">
        $(document).ready (function (){
            $('.select2').select2();
            <?php if($SubmitButtonText != 'View'): ?>
                $("#member").hide();
                $("#payment").hide();
                $("#buy_price_div").hide();
                $("#no_token").hide();
            <?php endif; ?>
        });

        function showother_payment()
        {
            selectBox = document.getElementById("type");
            if(selectBox.options[selectBox.selectedIndex].value == 'piutang_transaction')
            {
                $("#member").show();
                $("#payment").show();
                $("#buy_price_div").hide();
                $("#no_token").hide();
            }
            else if(selectBox.options[selectBox.selectedIndex].value == 'pulsa_transaction')
            {
                $("#member").hide();
                $("#payment").show();
                $("#buy_price_div").show();
                $("#no_token").show();
            }
            else
            {
                $("#member").hide();
                $("#payment").hide();
                $("#buy_price_div").hide();
                $("#no_token").hide();
            }
        }


        function formatNumber(name)
        {
            num = document.getElementById(name).value;
            num = num.toString().replace(/,/g,'');
            document.getElementById(name).value = num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
        }
    </script>
<?php $__env->stopSection(); ?><?php /**PATH C:\project_caca\kuncen\resources\views/layout/other-transaction/form.blade.php ENDPATH**/ ?>