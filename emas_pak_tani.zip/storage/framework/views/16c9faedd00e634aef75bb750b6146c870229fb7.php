<div class="content-wrapper">

  <?php echo $__env->make('layout' . '.alert-message', ['type' => $default['type'], 'data' => $default['data'], 'color' => $default['color']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title">Daftar Gambar <a href="<?php echo e(url($role . '/good/' . $good->id . '/detail')); ?>"><?php echo e($good->name); ?> (<?php echo e($good->code); ?>)</a></h3>
          </div>
          <div class="box-body" style="overflow-x:scroll">
            <?php $__currentLoopData = $good->good_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-sm-4">
                <img src="<?php echo e(URL::to('image/' . $photo->location)); ?>" style="height: 300px;"><br>

                <button type="button" class="no-btn" data-toggle="modal" data-target="#modal-danger-<?php echo e($photo->id); ?>"><i class="fa fa-times red" aria-hidden="true"></i> Hapus foto</button>

                <?php echo $__env->make('layout' . '.delete-modal', ['id' => $photo->id, 'data' => 'foto ' . $good->name, 'formName' => 'delete-form-' . $photo->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <form id="delete-form-<?php echo e($photo->id); ?>" action="<?php echo e(url($role . '/good/' . $good->id . '/photo/' . $photo->id . '/delete')); ?>" method="POST" style="display: none;">
                  <?php echo e(csrf_field()); ?>

                  <?php echo e(method_field('DELETE')); ?>

                </form>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<?php $__env->startSection('js-addon'); ?>
  <script type="text/javascript">
    $(document).ready(function(){
      
        $("#search-input").keyup( function(e){
          if(e.keyCode == 13)
          {
            ajaxFunction();
          }
        });

        $("#search-btn").click(function(){
            ajaxFunction();
        });

    });
  </script>
<?php $__env->stopSection(); ?><?php /**PATH C:\project_caca\kuncen\resources\views/layout/good-photo/all.blade.php ENDPATH**/ ?>