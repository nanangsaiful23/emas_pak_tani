<div class="content-wrapper">
  <?php echo $__env->make('layout' . '.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title"> Form Edit Brand</h3>
          </div>

		      <?php echo Form::model($brand, array('url' => route($role . '.brand.update', $brand->id), 'method' => 'POST', 'class' => 'form-horizontal')); ?>

            <div class="box-body">
              <?php echo $__env->make('layout' . '.brand.form', ['SubmitButtonText' => 'Edit'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			        <?php echo e(method_field('PUT')); ?>

            </div>
          <?php echo Form::close(); ?>


        </div>
      </div>
    </div>
  </section>
</div><?php /**PATH C:\project_caca\kuncen\resources\views/layout/brand/edit.blade.php ENDPATH**/ ?>