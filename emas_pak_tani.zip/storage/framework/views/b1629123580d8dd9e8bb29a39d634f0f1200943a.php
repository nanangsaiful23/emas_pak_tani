<html>
	<style type="text/css">
		@page  
		{ 
			size: 70mm 12mm;  
/*			size: landscape;*/
/*			margin: 0.1in; */
		}

		@media  print
		{
			@page  
			{ 
				size: 70mm 12mm;  
/*				size: landscape;*/
/*				margin: 0.1in; */
			}
		}

		table {
		  border-collapse: collapse;
		}

		table, th, td {
/*		  border: 0.1px solid black;*/
			color: darkblue;
		}
	</style>
	<script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
	<body>
		<table class="space-top-2">
			<tbody>	
				<?php $i = 0; ?>
				<?php while(isset($goods[$i])): ?>
					<tr>
						<?php for($j = 0; $j < 4; $j++): ?>
							<?php if(isset($goods[$i * 4 + $j])): ?>
				            	<td style="width: 25mm; height: 12mm">
					            	<div style="text-align: center;">
						            	<span style="font-size: 5px;"><?php echo DNS1D::getBarcodeSVG($goods[$i * 4 + $j]['code'], 'C39', 0.65, 20, 'black', false); ?></span><br>
						            	<span style="font-size: 5px;"><b><?php echo e($goods[$i * 4 + $j]['name'] . ' (' . $goods[$i * 4 + $j]['code'] . ')'); ?></b></span><br>
						            	<span style="font-size: 5px;"><b><?php echo e(showRupiah($goods[$i * 4 + $j]['price'])); ?></b></span>
					            	</div>
					            </td>
				            	<td style="width: 20mm; height: 12mm">
					            	<div style="text-align: center;">
					            	</div>
					            </td>
				            	<td style="width: 25mm; height: 12mm">
					            	<div style="text-align: center;">
						            	<span style="font-size: 5px;"><?php echo DNS1D::getBarcodeSVG($goods[$i * 4 + $j]['code'], 'C39', 0.65, 20, 'black', false); ?></span><br>
						            	<span style="font-size: 5px;"><b><?php echo e($goods[$i * 4 + $j]['name'] . ' (' . $goods[$i * 4 + $j]['code'] . ')'); ?></b></span><br>
						            	<span style="font-size: 5px;"><b><?php echo e(showRupiah($goods[$i * 4 + $j]['price'])); ?></b></span>
					            	</div>
					            </td>
				            <?php endif; ?>
						<?php endfor; ?>
						<?php $i++; ?>
					</tr>
					<?php if($i % 6 == 0 && $i > 0): ?> 
						<tr style="opacity: 0; border: 0px !important;">
							<?php for($j = 0; $j < 4; $j++): ?>
								<td style="border: 0px !important;"><?php echo e($i); ?></td>
							<?php endfor; ?>
						</tr>
					<?php endif; ?>
				<?php endwhile; ?> 
			</tbody>
		</table>
	</body>

	<script type="text/javascript">		
        $(document).ready (function (){
        	window.print();
        }); 

	    window.setTimeout(function(){
      		window.location = window.location.origin + '/<?php echo e($role); ?>/print-barcode/rack';
	    }, 5000);
	</script>
</html><?php /**PATH C:\project_caca\emas_pak_tani\resources\views/layout/good/print-barcode.blade.php ENDPATH**/ ?>