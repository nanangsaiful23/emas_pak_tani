<?php if($type != null): ?>
	<?php if($type == 'error'): ?>
		<div class="alert alert-<?php echo e($color); ?> alert-dismissible" id="message">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				<h4><i class="icon fa fa-warning"></i> <?php echo e($data); ?></h4>
		</div>
	<?php else: ?>
		<div class="alert alert-<?php echo e($color); ?> alert-dismissible" id="message">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				<h4><i class="icon fa fa-warning"></i> <?php echo e($data); ?> berhasil di <?php echo e($type); ?></h4>
		</div>
	<?php endif; ?>
<?php endif; ?><?php /**PATH C:\project_caca\emas_pak_tani\resources\views/layout/alert-message.blade.php ENDPATH**/ ?>