<div class="modal modal-danger fade" id="modal-danger-<?php echo e($id); ?>">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Hapus <?php echo e($data); ?></h4>
      </div>
      <div class="modal-body">
          <p>Anda yakin ingin menghapus <?php echo e($data); ?>?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-outline" onclick="event.preventDefault(); document.getElementById('<?php echo e($formName); ?>').submit();">Hapus</button>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\project_caca\emas_pak_tani\resources\views/layout/delete-modal.blade.php ENDPATH**/ ?>