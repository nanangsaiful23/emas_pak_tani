<div class="panel-body" style="color: black !important;">
    <div class="row">
        <div class="form-group">
            <?php echo Form::label('code', 'Kode', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('code', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <?php echo Form::text('code', null, array('class' => 'form-control')); ?>

                <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <?php echo Form::label('name', 'Nama', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('name', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <?php echo Form::text('name', null, array('class' => 'form-control')); ?>

                <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <?php echo Form::label('eng_name', 'English Name', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('eng_name', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <?php echo Form::text('eng_name', null, array('class' => 'form-control')); ?>

                <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <?php echo Form::label('quantity', 'Kuantitas', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('quantity', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <?php echo Form::text('quantity', null, array('class' => 'form-control')); ?>

                <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <?php echo Form::label('base', 'Satuan', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('base', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <?php echo Form::text('base', null, array('class' => 'form-control')); ?>

                <?php endif; ?>
            </div>
        </div>
        
        <div class="form-group">
            <?php echo e(csrf_field()); ?>


            <div class="col-sm-5">
                <hr>
                <?php if($SubmitButtonText == 'Edit'): ?>
                    <?php echo Form::submit($SubmitButtonText, ['class' => 'btn form-control']); ?>

                <?php elseif($SubmitButtonText == 'Tambah'): ?>
                    <?php echo Form::submit($SubmitButtonText, ['class' => 'btn form-control']); ?>

                <?php elseif($SubmitButtonText == 'View'): ?>
                    <a href="<?php echo e(url($role . '/unit/' . $unit->id . '/edit')); ?>" class="btn form-control">Ubah Data Satuan</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php echo Form::close(); ?>


<?php $__env->startSection('js-addon'); ?>
<?php $__env->stopSection(); ?><?php /**PATH C:\project_caca\kuncen\resources\views/layout/unit/form.blade.php ENDPATH**/ ?>