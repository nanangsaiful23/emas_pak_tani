<div class="content-wrapper">
  <?php echo $__env->make('layout' . '.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title"> Form Detail Transaksi <?php echo e($transaction->created_at); ?></h3>
          </div>

          <?php echo Form::model($transaction, array('class' => 'form-horizontal')); ?>

            <div class="box-body">
                <div class="panel-body">
                    <div class="row">
                        <div class="form-group">
                            <?php echo Form::label('actor', 'PIC', array('class' => 'col-sm-2 control-label')); ?>

                            <div class="col-sm-4">
                                <?php echo Form::text('actor', $transaction->actor()->name, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('total_item_price', 'Total Harga', array('class' => 'col-sm-2 control-label')); ?>

                            <div class="col-sm-4">
                                <?php echo Form::text('total_item_price', showRupiah($transaction->total_item_price), array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('total_discount_price', 'Total Diskon', array('class' => 'col-sm-2 control-label')); ?>

                            <div class="col-sm-4">
                                <?php echo Form::text('total_discount_price', showRupiah($transaction->details->sum('discount_price')), array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('total_discount_price', 'Total Potongan Akhir', array('class' => 'col-sm-2 control-label')); ?>

                            <div class="col-sm-4">
                                <?php echo Form::text('total_discount_price', showRupiah($transaction->total_discount_price), array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('total_sum_price', 'Total Akhir', array('class' => 'col-sm-2 control-label')); ?>

                            <div class="col-sm-4">
                                <?php echo Form::text('total_sum_price', showRupiah($transaction->total_sum_price), array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('money_paid', 'Total Uang', array('class' => 'col-sm-2 control-label')); ?>

                            <div class="col-sm-4">
                                <?php echo Form::text('money_paid', showRupiah($transaction->money_paid), array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('money_returned', 'Kembalian', array('class' => 'col-sm-2 control-label')); ?>

                            <div class="col-sm-4">
                                <?php echo Form::text('money_returned', showRupiah($transaction->money_returned), array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                            </div>
                        </div>
                    </div>

                    <div class="form-group col-sm-12" style="overflow-x:scroll">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <th>Barcode</th>
                                <th>Nama</th>
                                <th>Jumlah</th>
                                <?php if(\Auth::user()->email == 'admin'): ?>
                                    <th>Harga Beli</th> 
                                <?php endif; ?>
                                <th>Harga Jual</th>
                                <th>Total Diskon</th>
                                <th>Total Akhir</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $transaction->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr <?php if($detail->type == 'retur'): ?> style="background-color: yellow" <?php endif; ?>>
                                        <td>
                                            <?php echo e($detail->good_unit->good->code); ?>

                                        </td>
                                        <td>
                                            <?php echo e($detail->good_unit->good->name . ' ' . $detail->good_unit->unit->name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($detail->quantity); ?>

                                        </td>
                                        <?php if(\Auth::user()->email == 'admin'): ?>
                                            <td style="text-align: right;">
                                                <?php echo e(showRupiah($detail->buy_price)); ?>

                                            </td>
                                        <?php endif; ?>
                                        <td style="text-align: right;">
                                            <?php echo e(showRupiah($detail->selling_price)); ?>

                                        </td>
                                        <td style="text-align: right;">
                                            <?php echo e(showRupiah($detail->discount_price)); ?>

                                        </td>
                                        <td style="text-align: right;">
                                            <?php if($detail->type == 'retur'): ?> - <?php endif; ?> <?php echo e(showRupiah($detail->sum_price)); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <?php echo Form::close(); ?>


                </div>
            </div>
        </div>
    </div>
</div>
    </section>
</div>

<style type="text/css">
    .select2-container--default .select2-selection--multiple .select2-selection__choice {
        background-color: rgb(60, 141, 188) !important;
    }
</style>
<?php $__env->startSection('js-addon'); ?>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\project_caca\emas_pak_tani\resources\views/layout/transaction/detail.blade.php ENDPATH**/ ?>