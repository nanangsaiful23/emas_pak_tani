<div class="content-wrapper">
  <?php echo $__env->make('layout' . '.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title"> Form Detail Loading</h3>
          </div>

          <?php echo Form::model($good_loading, array('class' => 'form-horizontal')); ?>

            <div class="box-body">
                <div class="panel-body">
                    <div class="row">
                        <div class="form-group">
                            <?php echo Form::label('distributor_id', 'Distributor', array('class' => 'col-sm-2 control-label')); ?>

                            <div class="col-sm-4">
                                <?php echo Form::text('distributor', $good_loading->distributor->name, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                            </div>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('loading_date', 'Tanggal Pembelian', array('class' => 'col-sm-2 control-label')); ?>

                            <div class="col-sm-4">
                                <?php echo Form::text('loading_date', displayDate($good_loading->loading_date), array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('note', 'Catatan', array('class' => 'col-sm-2 left control-label')); ?>

                            <div class="col-sm-4">
                                <?php echo Form::text('note', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('checker', 'PIC Check Barang', array('class' => 'col-sm-2 control-label')); ?>

                            <div class="col-sm-4">
                                <?php echo Form::text('checker', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('total_item_price', 'Total Harga', array('class' => 'col-sm-2 control-label')); ?>

                            <div class="col-sm-4">
                                <?php echo Form::text('total_item_price', showRupiah($good_loading->total_item_price), array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                            </div>
                        </div>
                    </div>

                    <div class="form-group col-sm-12" style="overflow-x:scroll">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <th>Barcode</th>
                                <th>Nama</th>
                                <th>Expired</th>
                                <th>Jumlah Input</th>
                                <th>Jumlah Real</th>
                                <th>Harga Beli</th>
                                <th>Total Harga</th>
                                <th>Stock Sebelumnya</th>
                                <th>Harga Jual</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $good_loading->detailsWithDeleted(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr <?php if($detail->good->deleted_at != null): ?> style="background-color: red" <?php endif; ?>>
                                        <td>
                                            <a href="<?php echo e(url($role . '/good/' . $detail->good->id . '/loading/2023-01-01/' . date('Y-m-d') . '/10')); ?>" class="btn" target="_blank()">
                                            <?php echo e($detail->good->code); ?></a>
                                        </td>
                                        <td>
                                            <?php echo e($detail->good->name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($detail->expiry_date); ?>

                                        </td>
                                        <td>
                                            <?php echo e($detail->quantity . ' @' . $detail->good_unit->unit->name . ' (' . $detail->good_unit->unit->code . ')'); ?>

                                        </td>
                                        <td>
                                            <?php echo e($detail->real_quantity . ' ' . $detail->good_unit->unit->base); ?>

                                        </td>
                                        <td style="text-align: right;">
                                            <?php echo e(showRupiah($detail->price)); ?>

                                        </td>
                                        <td style="text-align: right;">
                                            <?php echo e(showRupiah($detail->quantity * $detail->price)); ?>

                                        </td>
                                        <td>
                                            <?php echo e(checkNull($detail->last_stock)); ?>

                                        </td>
                                        <td style="text-align: right;">
                                            <?php echo e(showRupiah($detail->selling_price)); ?>

                                            <?php if(\Auth::user()->email == 'admin'): ?>
                                              <br>Untung: <?php echo e(showRupiah(roundMoney($detail->selling_price) - $detail->price) . ' (' . calculateProfit($detail->price, roundMoney($detail->selling_price))); ?>%)<br>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <?php echo Form::close(); ?>


                </div>
            </div>
        </div>
    </div>
</div>
    </section>
</div>

<style type="text/css">
    .select2-container--default .select2-selection--multiple .select2-selection__choice {
        background-color: rgb(60, 141, 188) !important;
    }
</style>
<?php $__env->startSection('js-addon'); ?>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\project_caca\kuncen\resources\views/layout/good-loading/detail.blade.php ENDPATH**/ ?>