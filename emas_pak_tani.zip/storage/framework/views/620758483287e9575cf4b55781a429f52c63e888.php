<style type="text/css">
    .select2-container--default .select2-selection--multiple .select2-selection__choice {
        background-color: rgb(60, 141, 188) !important;
    }
</style>

<div class="panel-body">
    <?php $goods = getGoods() ?>
    <?php $distributors = getDistributors() ?>
    <div class="row">
        <div class="col-sm-5">
            <div class="form-group col-sm-12">
                <?php echo Form::label('distributor_id', 'Distributor', array('class' => 'col-sm-4 control-label')); ?>

                <div class="col-sm-8">
                    <?php if($SubmitButtonText == 'View'): ?>
                        <?php echo Form::text('distributor', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                    <?php else: ?>
                        <input type="text" name="distributor_name" class="form-control" id="distributor_name">
                        <select class="form-control select2" style="width: 100%;" name="distributor_id" id="all_distributor">
                            <div>
                                <option value="null">Silahkan pilih distributor</option>
                                <?php $__currentLoopData = $distributors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $distributor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($distributor->id); ?>">
                                    <?php echo e($distributor->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </select>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group col-sm-12">
                <?php echo Form::label('loading_date', 'Tanggal Pembelian', array('class' => 'col-sm-4 control-label')); ?>

                <div class="col-sm-8">
                    <div class="input-group date">
                        <input type="text" class="form-control pull-right" required="required" name="loading_date" id="loading_date">
                    </div>
                </div>
            </div>
        </div>
       <div class="col-sm-7">
            <?php echo Form::label('note', 'Catatan', array('class' => 'col-sm-1 left control-label')); ?>

            <div class="col-sm-12">
                <input type="text" name="note" class="form-control" id="note">
            </div>
            <?php echo Form::label('checker', 'PIC Check Barang', array('class' => 'col-sm-12 control-label', 'style' => 'text-align: left')); ?>

            <div class="col-sm-12">
                <input type="text" name="checker" class="form-control" id="checker">
            </div>
            <?php echo Form::label('payment', 'Jenis Pembayaran', array('class' => 'col-sm-12 control-label', 'style' => 'text-align: left')); ?>

            <div class="col-sm-12">
                <select class="form-control select2" style="width: 100%;" name="payment">
                    <div>
                        <option value="1111">1111 - Kas di Tangan</option>
                        <option value="1112">1112 - Kas di Bank</option>
                        <option value="2101">2101 - Utang Dagang</option>
                    </div>
                </select>
            </div>
       </div>
    </div>

    <h4>Barang Lama</h4>
    <div class="row">
        <div class="form-group col-sm-5">
            <?php echo Form::label('all_barcode', 'Cari barcode', array('class' => 'col-sm-4 control-label')); ?>

            <div class="col-sm-8">
                <input type="text" name="all_barcode" class="form-control" id="all_barcode"
                    onchange="searchByBarcode()">
            </div>
        </div>
        <div class="form-group col-sm-7">
            <?php echo Form::label('all_name', 'Cari nama barang', array('class' => 'col-sm-3 control-label')); ?>

            <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="items" id="all_name"
                    onchange="searchItemByName()">
                    <div>
                        <option value="null">Silahkan pilih barang</option>
                        <?php $__currentLoopData = $goods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $good): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($good->id); ?>"><?php echo e($good->name . ' '); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </select>
            </div>
        </div>
        <div class="form-group col-sm-12" style="overflow-x:scroll">

        <table class="table table-bordered table-striped">
            <thead>
                <th>Barcode</th>
                <th>Nama</th>
                <th>Jumlah</th>
                <th>Persentase</th>
                <th>Berat</th>
                <th>Status Barang</th>
                <th>Stock Lama</th>
                <th>Stock Baru</th>
                <th>Harga Beli</th>
                <th>Total Harga</th>
                <th>Harga Jual</th>
                <th>Hapus</th>
            </thead>
            <tbody id="table-transaction">
                <?php $i = 1; ?>
                <tr id="row-data-<?php echo e($i); ?>">
                    <td>
                        <textarea type="text" name="barcodes[]" class="form-control" id="barcode-<?php echo e($i); ?>" style="height: 70px"></textarea>
                    </td>
                    <td width="20%">
                        <?php echo Form::textarea('name_temps[]', null, array('class' => 'form-control', 'readonly' => 'readonly', 'id' => 'name_temp-'.$i, 'style' => 'height: 70px')); ?>

                        <?php echo Form::text('names[]', null, array('id'=>'name-' . $i, 'style' => 'display:none')); ?>

                    </td>
                    <td>
                        <textarea type="text" name="quantities[]" class="form-control" id="quantity-<?php echo e($i); ?>"
                            onchange="editPrice('<?php echo e($i); ?>')" onkeypress="editPrice('<?php echo e($i); ?>')"></textarea>
                    </td>
                    <td>
                        <textarea type="text" name="percentages[]" class="form-control" id="percentage-<?php echo e($i); ?>"></textarea>
                    </td>
                    <td>
                        <textarea type="text" name="weights[]" class="form-control" id="weight-<?php echo e($i); ?>"></textarea>
                    </td>
                    <td>
                        <?php echo Form::textarea('statuses[]', null, array('class' => 'form-control', 'readonly' =>
                        'readonly', 'id' => 'status-'.$i, 'style' => 'height: 70px')); ?>

                    </td>
                    <td>
                        <?php echo Form::textarea('old_stocks[]', null, array('class' => 'form-control', 'readonly' =>
                        'readonly', 'id' => 'old_stock-'.$i, 'style' => 'height: 70px')); ?>

                    </td>
                    <td>
                        <?php echo Form::textarea('new_stocks[]', null, array('class' => 'form-control', 'readonly' =>
                        'readonly', 'id' => 'new_stock-'.$i, 'style' => 'height: 70px')); ?>

                    </td>
                    <td>
                         <textarea type="text" name="prices[]" class="form-control" id="price-<?php echo e($i); ?>"
                            onchange="editPrice('<?php echo e($i); ?>')" onkeypress="editPrice('<?php echo e($i); ?>')"></textarea>
                    </td>
                    <td>
                        <?php echo Form::textarea('total_prices[]', null, array('class' => 'form-control', 'readonly' =>
                        'readonly', 'id' => 'total_price-'.$i, 'style' => 'height: 70px')); ?>

                    </td>
                    <td>
                        <?php echo Form::textarea('sell_prices[]', null, array('class' => 'form-control', 'id' => 'sell_price-'.$i, 'style' => 'height: 70px')); ?>

                    </td>
                    <td><i class="fa fa-times red" id="delete-<?php echo e($i); ?>" onclick="deleteItem('<?php echo e($i); ?>')"></i></td>
                </tr>
            </tbody>
        </table>
        </div>
        <div class="form-group">
            <?php echo Form::label('total_item_price', 'Total Harga', array('class' => 'col-sm-3 control-label')); ?>

            <div class="col-sm-3">
                <?php echo Form::text('total_item_price', null, array('class' => 'form-control', 'readonly' => 'readonly', 'id'
                => 'total_item_price')); ?>

            </div>
        </div>
        <?php echo Form::hidden('type', $type); ?>

    </div>

    <?php echo e(csrf_field()); ?>


    <hr>
    <?php if($SubmitButtonText == 'Edit'): ?>
    <?php echo Form::submit($SubmitButtonText, ['class' => 'btn btn-warning btn-flat btn-block form-control']); ?>

    <?php elseif($SubmitButtonText == 'Tambah'): ?>
    <div onclick="event.preventDefault(); submitForm();" class='btn btn-success btn-flat btn-block form-control'>Proses
        Loading</div>
    <?php elseif($SubmitButtonText == 'View'): ?>
    <?php endif; ?>

    <h4>Barang Baru</h4>
    <div class="row">
        <div class="col-sm-5">
            <div class="form-group">
                <?php echo Form::label('category_id', 'Kategori', array('class' => 'col-sm-4 control-label')); ?>

                <div class="col-sm-8">
                    <?php echo Form::select('category_id', getCategories(), null, ['class' => 'form-control select2',
                    'style'=>'width: 100%', 'id' => 'category_id']); ?>

                </div>
            </div>
            <div class="form-group">
                <?php echo Form::label('code', 'Barcode Barang', array('class' => 'col-sm-4 control-label')); ?>

                <div class="col-sm-8">
                    <?php echo Form::text('code', null, array('class' => 'form-control', 'id' => 'code')); ?>

                    
                </div>
            </div>

            <div class="form-group">
                <?php echo Form::label('name', 'Nama Barang', array('class' => 'col-sm-4 control-label')); ?>

                <div class="col-sm-8">
                    <?php echo Form::text('name', null, array('class' => 'form-control','required'=>'required', 'id' => 'name')); ?>

                </div>
            </div>

            <div class="form-group">
                <?php echo Form::label('description', 'Deskripsi Barang', array('class' => 'col-sm-4 control-label')); ?>

                <div class="col-sm-8">
                    <?php echo Form::textarea('description', null, array('class' => 'form-control', 'id' => 'description')); ?>

                </div>
            </div>

            <div class="form-group">
                <?php echo Form::label('price', 'Harga Beli', array('class' => 'col-sm-4 control-label')); ?>

                <div class="col-sm-8">
                    <?php echo Form::text('price', null, array('class' => 'form-control', 'required'=>'required', 'id' => 'price')); ?>

                </div>
            </div>

            <div class="form-group">
                <?php echo Form::label('selling_price', 'Harga Jual', array('class' => 'col-sm-4 control-label')); ?>

                <div class="col-sm-8">
                    <?php echo Form::text('selling_price', null, array('class' => 'form-control', 'required'=>'required', 'id' => 'selling_price')); ?>

                </div>
            </div>

            <div class="form-group">
                <?php echo Form::label('percentage', 'Persentase', array('class' => 'col-sm-4 control-label')); ?>

                <div class="col-sm-8">
                    <?php echo Form::select('percentage', getPercentages(), null, ['class' => 'form-control select2',
                    'style'=>'width: 100%', 'id' => 'percentage']); ?>

                </div>
            </div>

            <div class="form-group">
                <?php echo Form::label('weight', 'Berat', array('class' => 'col-sm-4 control-label')); ?>

                <div class="col-sm-8">
                    <?php echo Form::text('weight', null, array('class' => 'form-control', 'required'=>'required', 'id' => 'weight')); ?>

                </div>
            </div>

            <div class="form-group">
                <?php echo Form::label('status', 'Status Barang', array('class' => 'col-sm-4 control-label')); ?>

                <div class="col-sm-8">
                    <?php echo Form::select('status', getStatus(), null, ['class' => 'form-control select2',
                    'style'=>'width: 100%', 'id' => 'status']); ?>

                </div>
            </div>

            <<!-- div class="form-group">
                <?php echo Form::label('file', 'File', array('class' => 'col-sm-4 control-label')); ?>

                <div class="col-sm-3">
                    <?php echo Form::file('file', NULL, array('class' => 'form-control', 'id' => 'file')); ?>

                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-offset-4 col-sm-8">
                    <input name="is_profile_picture" type="checkbox" value="1" checked="checked" id="is_profile_picture"> Jadikan gambar utama
                </div>
            </div> -->
        </div>
    </div>
    <div onclick="event.preventDefault(); addNewGood()" class='btn btn-success btn-flat btn-block form-control'>Tambah Barang Baru</div>
</div>

<?php echo Form::close(); ?>


<?php $__env->startSection('js-addon'); ?>
<script type="text/javascript">
    var total_item = 1;
    var total_real_item=0;
          $(document).ready (function (){
              $('.select2').select2();
              $("#all_barcode").focus();
                $('#loading_date').datepicker({
                    autoclose: true,
                    format: 'yyyy-mm-dd',
                    todayHighlight: true
                });
          });

          function fillItem(good,index)
          {
              var bool = false;
              console.log(good);
              if(good.length != 0)
              {
                  document.getElementById("name-" + total_item).value = good.id;
                  document.getElementById("name_temp-" + total_item).value = good.name;
                  document.getElementById("barcode-" + total_item).value = good.code;
                  $("#price-" + total_item).val(good.getPcsSellingPrice.buy_price);
                  $("#sell_price-" + total_item).val(good.getPcsSellingPrice.selling_price);
                  document.getElementById("quantity-" + total_item).value = 1;
                  document.getElementById("percentage-" + total_item).value = good.percentage;
                  document.getElementById("weight-" + total_item).value = good.weight;
                  document.getElementById("status-" + total_item).value = good.status;
                  document.getElementById("old_stock-" + total_item).value = good.old_stock;
                  document.getElementById("new_stock-" + total_item).value = parseInt(good.old_stock) + 1;

                  editPrice(total_item);
                  total_real_item += 1;
                  document.getElementById("all_barcode").value = '';
              }
              else
              {
                  alert('Barang tidak ditemukan');
                  document.getElementById("barcode-" + index).value = '';
                  document.getElementById("name-" + index).focus();
              }
          }

          function addNewGood()
          {
              var isi=true;
              if($("#category_id").val()==""){
                isi=false;
                alert("silahkan pilih kategori");
              }
              if($("#code").val()==""){
                isi=false;
                alert("silahkan isi kode");
              }
              if($("#name").val()==""){
                isi=false;
                alert("silahkan isi nama");
                console.log("ini sampai");
              }
              if($("#price").val()==""){
                isi=false;
                alert("silahkan isi harga beli");
                console.log("ini sampai");
              }
              if($("#selling_price").val()==""){
                isi=false;
                alert("silahkan isi harga jual");
                console.log("ini sampai");
              }
              if($("#percentage").val()==""){
                isi=false;
                alert("silahkan isi persentase");
                console.log("ini sampai");
              }
              if($("#weight").val()==""){
                isi=false;
                alert("silahkan isi berat");
                console.log("ini sampai");
              }
              if($("#status").val()==""){
                isi=false;
                alert("silahkan isi status");
                console.log("ini sampai");
              }
              // console.log($("#file").val());
              if(isi){
              $.ajax({
                url: "<?php echo url($role . '/good/store/'); ?>",
                type: 'POST',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: {
                    role: '<?php echo e($role); ?>',
                    category_id: $("#category_id").val(),
                    code: $("#code").val(),
                    name: $("#name").val(),
                    description: $("#description").val(),
                    percentage: $("#percentage").val(),
                    weight: $("#weight").val(),
                    price: $("#price").val(),
                    selling_price: $("#selling_price").val(),
                    status: $("#status").val(),
                    // file: $("#file").val(),
                    // is_profile_picture: $("#is_profile_picture").val(),
                },
                success: function(result){
                    console.log(result);
                    $("#name-" + total_item).val(result.good.id);
                    $("#barcode-" + total_item).val(result.good.code);
                    $("#name_temp-" + total_item).val(result.good.name);
                    $("#percentage-" + total_item).val(result.good.percentage);
                    $("#weight-" + total_item).val(result.good.weight);
                    $("#quantity-" + total_item).val("1");
                    $("#price-" + total_item).val(result.good.price);
                    $("#sell_price-" + total_item).val(result.good.selling_price);
                    $("#status-" + total_item).val(result.good.status);
                    $("#old_stock-" + total_item).val(0);

                    editPrice(total_item);

                    total_real_item+=1;

                    $("#code").val("");
                    $("#name").val("");
                    $("#description").val("");
                    $("#price").val("");
                    $("#selling_price").val("");
                    $("#percentage").val("");
                    $("#weight").val("");
                    // $("#status").val("");
                },
                error: function(){
                    // console.log('error');
                }
              });
              };
          }

          function searchByBarcode()
          {

              $.ajax({
                url: "<?php echo url($role . '/good/searchByBarcode/'); ?>/" + $("#all_barcode").val(),
                success: function(result){
                  var good = result.good;
                  var index=-1;

                  fillItem(result.good,index)},
                error: function(){
                }
              });
          }


          function searchItemByName()
          {
            console.log("<?php echo url($role . '/good/searchById/'); ?>/" + $("#all_name").val());
              $.ajax({
                url: "<?php echo url($role . '/good/searchById/'); ?>/" + $("#all_name").val(),
                success: function(result){
                    var index=-1;
                    var r = result.units;

                    for (var i = 0; i < r.length; i++) {
                        const getPcsSellingPrice = {unit_id: r[i].unit_id, buy_price: r[i].buy_price, selling_price: r[i].selling_price};
                        const good = {id: r[i].good_id, name: r[i].name, code: r[i].code, percentage: r[i].percentage, weight: r[i].weight, getPcsSellingPrice: getPcsSellingPrice, old_stock: r[i].stock, status: r[i].status};
                        console.log(good);
                        fillItem(good,index);
                    }
                },
                error: function(){
                }
              });
          }

          function checkQuantity(index)
          {
              $.ajax({
                url: "<?php echo url($role . '/good/checkQuantity/'); ?>/" + $("#name-" + index).val() + '/' + $("#quantity-" + index).val(),
                success: function(result){
                  var status = result.status;

                  if(status == 'ok')
                  {
                      // changePrice(index);
                  }
                  else
                  {
                      alert('Barang tidak mencukupi');
                  }
                },
                error: function(){
                }
              });
          }

          function changeFocus(index)
          {
              $("#barcode-" + index).focus();
          }

          function changeTotal()
          {
              total_item_price = parseInt(0);
              total_promo_price = parseInt(0);
              for (var i = 1; i <= total_item; i++)
              {
                  if(document.getElementById("barcode-" + i))
                  {
                      if(document.getElementById("barcode-" + i).value != '')
                      {
                          money = document.getElementById("total_price-" + i).value;
                          money = money.replace(/,/g,'');
                          total_item_price += parseInt(money);

                      }
                  }
              }

              document.getElementById("total_item_price").value = total_item_price;

              formatNumber("total_item_price");

          }

          function changeTotalSum()
          {
              if(document.getElementById("total_discount_price").value == '')
              {
                  // alert("Silahkan isi potongan harga");
              }
              else
              {
                  changeTotal();

                  total = document.getElementById("total_sum_price").value;
                  total = total.replace(/,/g,'');

                  discount = document.getElementById("total_discount_price").value;
                  discount = discount.replace(/,/g,'');
                  total_sum_price = parseInt(total) - parseInt(discount);

                  document.getElementById("total_sum_price").value = total_sum_price;
                  formatNumber("total_sum_price");

                  changeReturn();
              }
          }

          function submitForm()
          {
              var isi=true;
              if ( $("#distributor").val()==""){
                isi=false;
                alert("silahkan isi distributor");
              }
              if ( $("#loading_date").val()==""){
                isi=false;
                alert("silahkan isi tanggal pembelian");
              }
              if(total_real_item == 0 )
              {
                  alert('Silahkan pilih barang');
                  isi=false;
              }
              if(isi)
              {
                  document.getElementById('loading-form').submit();
                  // alert('hay');
              }

          }

          function formatNumber(name)
          {
              num = document.getElementById(name).value;
              num = num.toString().replace(/,/g,'');
              document.getElementById(name).value = num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
          }
          function unFormatNumber(num)
          {
              return num.replace(/,/g,'');

          }
          function deleteItem(index)
          {
              $("#row-data-" + index).remove();
              total_real_item-=1;
              changeTotal();
          }
          function editPrice(index)
          {
              document.getElementById("total_price-" + index).value = unFormatNumber(document.getElementById("price-" + index).value) * unFormatNumber(document.getElementById("quantity-" + index).value);
              document.getElementById("new_stock-" + index).value = parseInt(document.getElementById("old_stock-" + index).value) + parseInt(document.getElementById("quantity-" + index).value);

              formatNumber("total_price-" + index);

              changeTotal();
              temp1=parseInt(index)+1
              htmlResult = '<tr id="row-data-' + temp1+ '"><td><textarea type="text" name="barcodes[]" class="form-control" id="barcode-' + temp1+ '" onchange="searchName(' + temp1+ ')"></textarea></td><td width="20%"><textarea  class="form-control" readonly="readonly" id="name_temp-' + temp1+ '" name="name_temps[]" type="text" style="height: 70px"></textarea><textarea id="name-' + temp1 + '" name="names[]" type="text" style="display:none"></textarea></td><td><textarea type="text" name="quantities[]" class="form-control" id="quantity-' + temp1+'" onkeypress="editPrice(' + temp1+')" onchange="editPrice(' + temp1+ ')"></textarea></td><td><textarea class="form-control" id="percentage-' + temp1 + '" name="percentages[]" type="text"></textarea></td><td><textarea class="form-control" id="weight-' + temp1 + '" name="weights[]" type="text"></textarea></td><td><textarea class="form-control" readonly="readonly" id="status-' + temp1+ '" name="statuses[]" type="text"></textarea></td><td><textarea class="form-control" readonly="readonly" id="old_stock-' + temp1+ '" name="old_stocks[]" type="text"></textarea></td><td><textarea class="form-control" readonly="readonly" id="new_stock-' + temp1+ '" name="new_stocks[]" type="text"></textarea></td><td><textarea type="text" name="prices[]" class="form-control" id="price-' + temp1+'" onkeypress="editPrice(' + temp1+')" onchange="editPrice(' + temp1+ ')"></textarea></td><td><textarea class="form-control" readonly="readonly" id="total_price-' + temp1+ '" name="total_prices[]" type="text"></textarea></td><td><textarea class="form-control" id="sell_price-' + temp1+ '" name="sell_prices[]" type="text"></textarea></td><td><i class="fa fa-times red" id="delete-' + temp1+'" onclick="deleteItem('
              + temp1+ ')"></i></td></tr>';
              if(index == total_item)
              {
                  total_item += 1;
                  $("#table-transaction").prepend(htmlResult);
                  // $("#table-transaction").append(s);
              }
              document.getElementById("all_barcode").value = '';
              // $("#all_barcode").focus();

          }

        function changePriceByUnit(index)
        {
          $.ajax({
            url: "<?php echo url($role . '/good/getPriceUnit/'); ?>/" + $("#name-" + index).val() + '/' + $("#unit-" + index).val(),
            success: function(result){
              var good_unit = result.good_unit;

              if(good_unit != null)
              {
                  document.getElementById("price-" + index).value = good_unit.buy_price;
                  document.getElementById("sell_price-" + index).value = good_unit.selling_price;
              }
              else
              {
                  document.getElementById("price-" + index).value = '0';
                  document.getElementById("sell_price-" + index).value = '0';
              }

              document.getElementById("total_price-" + index).value = document.getElementById("price-" + index).value * document.getElementById("quantity-" + index).value;

              changeTotal();
            },
            error: function(){
            }
          });
        }
</script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\project_caca\emas_pak_tani\resources\views/layout/good-loading/form.blade.php ENDPATH**/ ?>