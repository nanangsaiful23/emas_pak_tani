<div class="content-wrapper">

  <?php echo $__env->make('layout' . '.alert-message', ['type' => $default['type'], 'data' => $default['data'], 'color' => $default['color']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title">List Distributor</h3>
            <?php echo $__env->make('layout.search-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
          <div class="box-body" style="overflow-x:scroll; color: black !important">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>Nama</th>
                <th>Lokasi</th>
                <th class="center">Detail</th>
                <th class="center">Ubah</th>
                <?php if($role == 'admin'): ?>
                  <th class="center">Hapus</th>
                <?php endif; ?>
              </tr>
              </thead>
              <tbody id="table-good">
                <?php $__currentLoopData = $distributors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $distributor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($distributor->name); ?></td>
                    <td><?php echo e($distributor->location); ?></td>
                    <td class="center"><a href="<?php echo e(url($role . '/distributor/' . $distributor->id . '/detail')); ?>"><i class="fa fa-hand-o-right tosca" aria-hidden="true"></i></a></td>
                    <td class="center"><a href="<?php echo e(url($role . '/distributor/' . $distributor->id . '/edit')); ?>"><i class="fa fa-file orange" aria-hidden="true"></i></a></td>
                    <?php if($role == 'admin'): ?>
                      <td class="center">
                        <button type="button" class="no-btn center" data-toggle="modal" data-target="#modal-danger-<?php echo e($distributor->id); ?>"><i class="fa fa-times" aria-hidden="true" style="color: red !important"></i></button>

                        <?php echo $__env->make('layout' . '.delete-modal', ['id' => $distributor->id, 'data' => $distributor->name, 'formName' => 'delete-form-' . $distributor->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <form id="delete-form-<?php echo e($distributor->id); ?>" action="<?php echo e(url($role . '/distributor/' . $distributor->id . '/delete')); ?>" method="POST" style="display: none;">
                          <?php echo e(csrf_field()); ?>

                          <?php echo e(method_field('DELETE')); ?>

                        </form>
                      </td>
                    <?php endif; ?>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <div id="renderField">
                <?php if($pagination != 'all'): ?>
                  <?php echo e($distributors->render()); ?>

                <?php endif; ?>
              </div>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<?php $__env->startSection('js-addon'); ?>
  <script type="text/javascript">
    $(document).ready(function(){
      
        $("#search-input").keyup( function(e){
          if(e.keyCode == 13)
          {
            ajaxFunction();
          }
        });

        $("#search-btn").click(function(){
            ajaxFunction();
        });

    });
  </script>
<?php $__env->stopSection(); ?><?php /**PATH C:\project_caca\kuncen\resources\views/layout/distributor/all.blade.php ENDPATH**/ ?>