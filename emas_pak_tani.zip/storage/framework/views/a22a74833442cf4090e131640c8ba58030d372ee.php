<div class="content-wrapper">

  <?php echo $__env->make('layout' . '.alert-message', ['type' => $default['type'], 'data' => $default['data'], 'color' => $default['color']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title"><?php echo e($default['page_name']); ?></h3>
          </div>
          <div class="box-body">
            <?php echo Form::label('category', 'Kategori', array('class' => 'col-sm-1 control-label')); ?>

            <div class="col-sm-2">
              <?php echo Form::select('category', getCategories(), $category_id, ['class' => 'form-control select2', 'style'=>'width: 100%', 'id' => 'category', 'onchange' => 'advanceSearch()']); ?>

            </div>
            <?php echo Form::label('distributor', 'Distributor', array('class' => 'col-sm-1 control-label')); ?>

            <div class="col-sm-2">
              <?php echo Form::select('distributor', getDistributorLists(), $distributor_id, ['class' => 'form-control select2', 'style'=>'width: 100%', 'id' => 'distributor', 'onchange' => 'advanceSearch()']); ?>

            </div>
            <?php echo Form::label('start_date', 'Tanggal Awal', array('class' => 'col-sm-1 control-label')); ?>

            <div class="col-sm-2">
              <div class="input-group date">
                <input type="text" class="form-control pull-right" id="datepicker" name="start_date" value="<?php echo e($start_date); ?>" onchange="changeDate()">
              </div>
            </div>
            <?php echo Form::label('end_date', 'Tanggal Akhir', array('class' => 'col-sm-1 control-label')); ?>

            <div class="col-sm-2">
              <div class="input-group date">
                <input type="text" class="form-control pull-right" id="datepicker2" name="end_date" value="<?php echo e($end_date); ?>" onchange="changeDate()">
              </div>
            </div>
          </div>
          <div class="box-body" style="overflow-x:scroll; color: black !important">
            <h3>Total transaksi: <?php echo e(showRupiah($total->sum('sum_price'))); ?></h3>
            <table id="example1" class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>Kode</th>
                <th>Nama</th>
                <th>Jumlah</th>
                <th>Unit</th>
                <th>Harga Beli</th>
                <th>Harga Jual</th>
                <th>Untung</th>
                <th>Total Penjualan</th>
                <th>Total Untung</th>
              </tr>
              </thead>
              <tbody id="table-good">
                <?php $__currentLoopData = $transaction_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $profit = calculateProfit($detail->buy_price, roundMoney($detail->selling_price)); ?>
                  <tr style="background-color: <?php if($detail->buy_price >= $detail->selling_price || $detail->buy_price == 0): ?> #D21312 <?php elseif($profit <= 10): ?> #FAE392 <?php elseif($profit <= 20): ?> #C3EDC0 <?php elseif($profit <= 30): ?> #F29727 <?php else: ?> #FF6D60 <?php endif; ?>">
                    <td><?php echo e($detail->code); ?></td>
                    <td><?php echo e($detail->name); ?></td>
                    <td><?php echo e($detail->quantity); ?></td>
                    <td><?php echo e($detail->unit_name); ?></td>
                    <td><?php echo e(showRupiah($detail->buy_price)); ?></td>
                    <td><?php echo e(showRupiah($detail->selling_price)); ?></td>
                    <td><?php echo e(showRupiah($detail->selling_price - $detail->buy_price)); ?><br><?php echo e($profit); ?>%</td>
                    <td><?php echo e(showRupiah($detail->selling_price * $detail->quantity)); ?></td>
                    <td><?php echo e(showRupiah(($detail->selling_price - $detail->buy_price) * $detail->quantity)); ?></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<?php $__env->startSection('js-addon'); ?>
  <script type="text/javascript">
    $(document).ready(function(){
        $('.select2').select2();
      $('#datepicker').datepicker({
        autoclose: true,
        format: 'yyyy-mm-dd'
      })

      $('#datepicker2').datepicker({
        autoclose: true,
        format: 'yyyy-mm-dd'
      })
        $("#search-input").keyup( function(e){
          if(e.keyCode == 13)
          {
            ajaxFunction();
          }
        });

        $("#search-btn").click(function(){
            ajaxFunction();
        });
    });

    function changeDate()
    {
      window.location = window.location.origin + '/<?php echo e($role); ?>/transaction/resume/<?php echo e($category_id); ?>/<?php echo e($distributor_id); ?>/' + $("#datepicker").val() + '/' + $("#datepicker2").val();
    }

    function advanceSearch()
    {

      window.location = window.location.origin + '/<?php echo e($role); ?>/transaction/resume/' + $('#category').val() + '/' + $('#distributor').val() + '/<?php echo e($start_date); ?>/<?php echo e($end_date); ?>';
    }
  </script>
<?php $__env->stopSection(); ?><?php /**PATH C:\project_caca\kuncen\resources\views/layout/transaction/resume.blade.php ENDPATH**/ ?>