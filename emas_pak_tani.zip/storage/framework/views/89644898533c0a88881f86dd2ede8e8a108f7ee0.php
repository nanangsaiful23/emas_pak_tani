<div class="panel-body" style="color: black !important;">
    <div class="row">
        <div class="form-group">
            <?php echo Form::label('category_id', 'Kategori', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('category', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <?php echo Form::select('category_id', getCategories(), $good->category_id, ['class' => 'form-control select2',
                    'style'=>'width: 100%', 'id' => 'brand_id']); ?>

                <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <?php echo Form::label('brand_id', 'Brand', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('brand', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <?php echo Form::select('brand_id', getBrands(), $good->brand_id, ['class' => 'form-control select2',
                    'style'=>'width: 100%', 'id' => 'brand_id']); ?>

                <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <?php echo Form::label('code', 'Kode/Barcode Barang', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('code', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <?php echo Form::text('code', null, array('class' => 'form-control')); ?>

                <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <?php echo Form::label('name', 'Nama Barang', array('class' => 'col-sm-12')); ?>

            <div class="col-sm-5">
                <?php if($SubmitButtonText == 'View'): ?>
                    <?php echo Form::text('name', null, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                <?php else: ?>
                    <?php echo Form::text('name', null, array('class' => 'form-control')); ?>

                <?php endif; ?>
            </div>
        </div>
        
        <div class="form-group">
            <?php echo e(csrf_field()); ?>


            <div class="col-sm-5">
                <hr>
                <?php if($SubmitButtonText == 'Edit'): ?>
                    <?php echo Form::submit($SubmitButtonText, ['class' => 'btn form-control']); ?>

                <?php elseif($SubmitButtonText == 'Tambah'): ?>
                    <?php echo Form::submit($SubmitButtonText, ['class' => 'btn form-control']); ?>

                <?php elseif($SubmitButtonText == 'View'): ?>
                    <a href="<?php echo e(url($role . '/good/' . $good->id . '/edit')); ?>" class="btn form-control">Ubah Data Barang</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php echo Form::close(); ?>


<?php $__env->startSection('js-addon'); ?>
  <script type="text/javascript">
    $(document).ready(function(){
        $('.select2').select2();
    });
</script>
<?php $__env->stopSection(); ?><?php /**PATH C:\project_caca\emas_pak_tani\resources\views/layout/good/form.blade.php ENDPATH**/ ?>