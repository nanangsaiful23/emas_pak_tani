<?php $__env->startSection('content'); ?>
  <style type="text/css">
    table, th, td
    {
      border: solid 2px black !important;
    }
  </style>

  <div class="content-wrapper">
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"><?php echo e($default['page_name']); ?></h3>
            </div>
            <div class="box-body">
              <?php echo Form::label('show', 'Show', array('class' => 'col-sm-1 control-label')); ?>

             <div class="col-sm-1">
                <?php echo Form::select('show', getPaginations(), $pagination, ['class' => 'form-control', 'style'=>'width: 100%', 'id' => 'show', 'onchange' => 'advanceSearch()']); ?>

              </div>
              <?php echo Form::label('distributor_id', 'Distributor', array('class' => 'col-sm-1 control-label')); ?>

             <div class="col-sm-2">
                <?php echo Form::select('distributor_id', getDistributorLists(), $distributor_id, ['class' => 'form-control select2', 'style'=>'width: 100%', 'id' => 'distributor_id', 'onchange' => 'advanceSearch()']); ?>

              </div>
              <?php echo Form::label('status', 'Status', array('class' => 'col-sm-1 control-label')); ?>

             <div class="col-sm-2">
                <?php echo Form::select('status', ['null' => 'Belum diretur', 'barang' => 'Pengembalian barang', 'uang' => 'Pengembalian uang'], $status, ['class' => 'form-control select2', 'style'=>'width: 100%', 'id' => 'status', 'onchange' => 'advanceSearch()']); ?>

              </div>
            </div>
            <div class="box-body" style="overflow-x:scroll; color: black !important">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Distributor</th>
                  <th>Nama Barang</th>
                  <th>Status</th>
                </tr>
                </thead>
                <tbody id="table-good">
                  <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($item->last_distributor->name); ?></td>
                      <td><?php echo e($item->good->name); ?></td>
                      <td>
                        <?php if($item->returned_date != null): ?>
                          Dikembalikan dalam bentuk <?php echo e($item->returned_type); ?> pada tanggal <?php echo e(displayDate($item->returned_date)); ?>

                        <?php else: ?>
                          Belum diretur<br>
                          <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#modal-retur-<?php echo e($item->id); ?>">Retur Barang</button>

                          <div class="modal modal-retur fade" id="modal-retur-<?php echo e($item->id); ?>">
                            <div class="modal-dialog">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title">Retur Barang <?php echo e($item->good->name); ?></h4>
                                </div>
                                <div class="modal-body">
                                    <p>Anda yakin ingin meretur <?php echo e($item->good->name); ?>?</p>
                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                                  <button type="button" class="btn btn-outline" onclick="event.preventDefault(); document.getElementById('uang-<?php echo e($item->id); ?>').submit();">Retur Uang</button>
                                  <button type="button" class="btn btn-outline" onclick="event.preventDefault(); document.getElementById('barang-<?php echo e($item->id); ?>').submit();">Retur Barang</button>
                                </div>
                              </div>
                            </div>
                          </div>

                          <form id="uang-<?php echo e($item->id); ?>" action="<?php echo e(url('admin/retur/' . $item->id)); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(form::hidden('type', 'uang')); ?>

                            <?php echo e(method_field('PUT')); ?>

                          </form>

                          <form id="barang-<?php echo e($item->id); ?>" action="<?php echo e(url('admin/retur/' . $item->id)); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(form::hidden('type', 'barang')); ?>

                            <?php echo e(method_field('PUT')); ?>

                          </form>
                        <?php endif; ?>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

  <?php $__env->startSection('js-addon'); ?>
    <script type="text/javascript">
      $(document).ready(function(){
          $('.select2').select2();
          $("#search-input").keyup( function(e){
            if(e.keyCode == 13)
            {
              ajaxFunction();
            }
          });

          $("#search-btn").click(function(){
              ajaxFunction();
          });

      });

    function advanceSearch()
    {
      var show           = $('#show').val();
      var distributor_id = $('#distributor_id').val();
      var status         = $('#status').val();
      window.location = window.location.origin + '/admin/retur/' + distributor_id + '/' + status + '/' + show;
    }
    </script>
  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.user', ['role' => 'admin', 'title' => 'Admin'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project_caca\kuncen\resources\views/admin/retur.blade.php ENDPATH**/ ?>