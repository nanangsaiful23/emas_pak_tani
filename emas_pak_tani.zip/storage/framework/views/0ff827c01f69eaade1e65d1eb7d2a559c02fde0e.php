<html>
	<style type="text/css">
		@page  
		{ 
			size: 8.27in 11.69in;  
			margin: 0.1in; 
		}

		@media  print
		{
			@page  
			{ 
				size: 8.27in 11.69in;  
				margin: 0.1in; 
			}
		}

		table {
		}

		table, th, td {
			color: darkblue;
			padding-left: 10px;
		}
	</style>
	<script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
	<body>
		<table class="space-top-2">
			<tbody>	
				<?php for($i = 0; $i < sizeof($goods); $i++): ?>
					<tr>
						<td width="80%"><h1><?php echo e($goods[$i]['name']); ?></h1></td>
						<td style="text-align: right;"><h1><?php echo e(showRupiah($goods[$i]['price'])); ?></h1></td>
					</tr>
				<?php endfor; ?>
			</tbody>
		</table>
    	<div style="text-align: right; margin-right: 50px;">
        	<span style="font-size: 10px;">ntnmart <?php echo e(date('d-m-Y')); ?></span>
    	</div>
	</body>

	<script type="text/javascript">		
        $(document).ready (function (){
        	window.print();
        }); 

	    // window.setTimeout(function(){
     //  		window.location = window.location.origin + '/<?php echo e($role); ?>/print-barcode/rack';
	    // }, 5000);
	</script>
</html><?php /**PATH C:\project_caca\kuncen\resources\views/layout/good/print-display-list.blade.php ENDPATH**/ ?>