<div class="content-wrapper">

  <?php echo $__env->make('layout' . '.alert-message', ['type' => $default['type'], 'data' => $default['data'], 'color' => $default['color']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title">Daftar transaksi</h3>
            <!-- <?php echo $__env->make('layout.search-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
          </div>
          <div class="box-body">
            <?php echo Form::label('show', 'Show', array('class' => 'col-sm-1 control-label')); ?>

           <div class="col-sm-1">
              <?php echo Form::select('show', getPaginations(), $pagination, ['class' => 'form-control', 'style'=>'width: 100%', 'id' => 'show', 'onchange' => 'advanceSearch()']); ?>

            </div>
            <?php if($role == 'admin'): ?>
              <?php echo Form::label('user_id', 'PIC', array('class' => 'col-sm-1 control-label')); ?>

              <div class="col-sm-2">
                <?php echo Form::select('user_id', getUsers(), $role_user . '/' . $role_id, ['class' => 'form-control select2', 'style'=>'width: 100%', 'id' => 'user_id', 'onchange' => 'advanceSearch()']); ?>

              </div>
            <?php endif; ?>
            <?php echo Form::label('start_date', 'Tanggal Awal', array('class' => 'col-sm-1 control-label')); ?>

            <div class="col-sm-2">
              <div class="input-group date">
                <input type="text" class="form-control pull-right" id="datepicker" name="start_date" value="<?php echo e($start_date); ?>" onchange="changeDate()">
              </div>
            </div>
            <?php echo Form::label('end_date', 'Tanggal Akhir', array('class' => 'col-sm-1 control-label')); ?>

            <div class="col-sm-2">
              <div class="input-group date">
                <input type="text" class="form-control pull-right" id="datepicker2" name="end_date" value="<?php echo e($end_date); ?>" onchange="changeDate()">
              </div>
            </div>
          </div>
          <div class="box-body" style="overflow-x:scroll;">
            <h3>Total transaksi hari ini: <?php echo e(showRupiah($transactions['cash']->sum('total_sum_price') + $transactions['credit']->sum('total_sum_price') + $transactions['transfer']->sum('total_sum_price') + $transactions['credit_transfer']->sum('total_sum_price') + $transactions['retur']->sum('total_sum_price'))); ?></h3>
            <!-- <h3>Total uang masuk cash: <?php echo e(showRupiah($transactions['cash']->sum('total_sum_price') + $transactions['credit']->sum('money_paid') + $transactions['retur']->sum('total_sum_price'))); ?></h4> -->
            <!-- <h3>Total uang masuk transfer: <?php echo e(showRupiah($transactions['transfer']->sum('total_sum_price') + ($transactions['credit_transfer']->sum('money_paid')))); ?></h4> -->
          </div>

          <?php echo $__env->make('layout.transaction.all-form', ['name' => 'Lunas', 'transactions' => $transactions['cash'], 'color' => '#E5F9DB', 'total_sum_price' => $transactions['cash']->sum('total_sum_price'), 'total_discount_price' => $transactions['cash']->sum('total_discount_price'), 'discount_price' => $transactions['cash']->sum('discount_price')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
      </div>
    </div>
  </section>
</div>

<?php $__env->startSection('js-addon'); ?>
  <script type="text/javascript">
    $(document).ready(function(){
      $('.select2').select2();
      $('#datepicker').datepicker({
        autoclose: true,
        format: 'yyyy-mm-dd'
      })

      $('#datepicker2').datepicker({
        autoclose: true,
        format: 'yyyy-mm-dd'
      })

      $("#search-input").keyup( function(e){
        if(e.keyCode == 13)
        {
          ajaxFunction();
        }
      });

      $("#search-btn").click(function(){
          ajaxFunction();
      });
    });

    function changeDate()
    {
      window.location = window.location.origin + '/<?php echo e($role); ?>/transaction/<?php echo e($role_user); ?>/<?php echo e($role_id); ?>/' + $("#datepicker").val() + '/' + $("#datepicker2").val() + '/<?php echo e($pagination); ?>';
    }

    function advanceSearch()
    {
      var show        = $('#show').val();
      var user_id     = $('#user_id').val();

      <?php if($role == 'cashier'): ?>
        user_id = 'all/all';
      <?php endif; ?>
      window.location = window.location.origin + '/<?php echo e($role); ?>/transaction/' + user_id + '/<?php echo e($start_date); ?>/<?php echo e($end_date); ?>/' + show;
    }
  </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\project_caca\emas_pak_tani\resources\views/layout/transaction/all.blade.php ENDPATH**/ ?>