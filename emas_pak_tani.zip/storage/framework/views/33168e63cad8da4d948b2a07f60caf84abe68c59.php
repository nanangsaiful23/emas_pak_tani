<style>
  .sidebar, li, span, i, a
  {
    color:  black;
    /*border-radius: 0px 10px 10px 0px;*/
  }

  .treeview-menu li, .treeview-menu li a {
    word-wrap: break-word;
    white-space: normal;
  }

  .header
  {
    background-color: #DDDDDD;
    font-weight: 500;
  }

  .treeview-menu .active a
  {
    background-color: #89CFFD;
  }
</style>

<aside class="main-sidebar" style="border-right: 0.5px; border: solid #DDDDDD;">
  <section class="sidebar">
    <ul class="sidebar-menu" data-widget="tree">
      <li class="header">MENU UTAMA</li>
      <li class="<?php echo e(Request::segment(1) == 'search' ? 'active' : ''); ?>"><a href="<?php echo e(url('/search/all')); ?>" target="_blank()"><i class="fa fa-search"></i> CARI BARANG</a></li>
      <li class="treeview <?php echo e((Request::segment(2) == 'good' ) ? 'active' : ''); ?>">
        <a href="#">
            <i class="fa fa-cubes"></i><span> Barang</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
            <li class="<?php echo e(Request::segment(2) == 'good' && Request::segment(3) != 'printDisplay' && Request::segment(3) != 'zeroStock' && Request::segment(3) != 'exp' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/good/all/all/20')); ?>"><i class="fa fa-circle-o"></i> Daftar Barang</a></li>
            <!-- <li class="<?php echo e(Request::segment(2) == 'good' && Request::segment(3) == 'exp' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/good/exp')); ?>"><i class="fa fa-circle-o"></i> Daftar Barang Expired</a></li> -->
            <li class="<?php echo e(Request::segment(2) == 'good' && Request::segment(3) == 'printDisplay' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/good/printBarcode')); ?>"><i class="fa fa-circle-o"></i> Print Barcode Barang</a></li>
            <?php if($role == 'admin'): ?>
              <li class="<?php echo e(Request::segment(2) == 'good' && Request::segment(3) == 'zeroStock' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/good/zeroStock/all/all/1/0')); ?>"><i class="fa fa-circle-o"></i> Stock Habis</a></li>
            <?php endif; ?>
        </ul>
      </li>
      <?php if($role == 'admin'): ?>
        <li class="treeview <?php echo e((Request::segment(2) == 'good-loading' && Request::segment(3) == 'loading' ) ? 'active' : ''); ?>">
          <a href="#">
              <i class="fa fa-truck"></i><span> Loading Barang</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
              <li class="<?php echo e(Request::segment(2) == 'good-loading' && Request::segment(4) == 'create' && Request::segment(3) == 'loading' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/good-loading/loading/create')); ?>"><i class="fa fa-circle-o"></i> Tambah Loading Barang</a></li>
              <li class="<?php echo e(Request::segment(2) == 'good-loading' && Request::segment(4) != 'create' && Request::segment(3) == 'loading' && Request::segment(4) != 'excel' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/good-loading/loading/' . date('Y-m-d') . '/' . date('Y-m-d') . '/all/50')); ?>"><i class="fa fa-circle-o"></i> Daftar Loading Barang</a></li>
          </ul>
        </li>
        <li class="treeview <?php echo e((Request::segment(2) == 'good-loading' && Request::segment(3) == 'buy' ) ? 'active' : ''); ?>">
          <a href="#">
              <i class="fa fa-dollar"></i><span> Beli Emas</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
              <li class="<?php echo e(Request::segment(2) == 'good-loading' && Request::segment(4) == 'create' && Request::segment(3) == 'buy' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/good-loading/buy/create')); ?>"><i class="fa fa-circle-o"></i> Tambah Pembelian Emas</a></li>
              <li class="<?php echo e(Request::segment(2) == 'good-loading' && Request::segment(4) != 'create' && Request::segment(3) == 'buy' && Request::segment(4) != 'excel' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/good-loading/buy/' . date('Y-m-d') . '/' . date('Y-m-d') . '/all/50')); ?>"><i class="fa fa-circle-o"></i> Daftar Pembelian Emas</a></li>
          </ul>
        </li>
      <?php endif; ?>
      <li class="treeview <?php echo e((Request::segment(2) == 'transaction' ) ? 'active' : ''); ?>">
        <a href="#">
            <i class="fa fa-money"></i><span> Penjualan Emas</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
            <li class="<?php echo e(Request::segment(2) == 'transaction' && Request::segment(3) == 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/transaction/create')); ?>"><i class="fa fa-circle-o"></i> Tambah Penjualan</a></li>
            <li class="<?php echo e(Request::segment(2) == 'transaction' && Request::segment(3) != 'create' && Request::segment(3) != 'resume' && Request::segment(3) != 'resumeTotal' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/transaction/all/all/' . date('Y-m-d') . '/' . date('Y-m-d') . '/20')); ?>"><i class="fa fa-circle-o"></i> Daftar Penjualan</a></li>
            <!-- <li class="<?php echo e(Request::segment(2) == 'transaction' && Request::segment(3) == 'resumeTotal' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/transaction/resumeTotal/' . date('Y-m-d') . '/' . date('Y-m-d'))); ?>"><i class="fa fa-circle-o"></i> Resume Transaksi Total</a></li>
            <?php if(\Auth::user()->email == 'admin'): ?>
              <li class="<?php echo e(Request::segment(2) == 'transaction' && Request::segment(3) == 'resume' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/transaction/resume/all/all/' . date('Y-m-d') . '/' . date('Y-m-d'))); ?>"><i class="fa fa-circle-o"></i> Resume Transaksi Per Barang</a></li>
            <?php endif; ?> -->
        </ul>
      </li>
      <!-- <li class="<?php echo e(Request::segment(2) == 'retur' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/retur/all/null/20')); ?>"><i class="fa fa-arrow-left"></i> Barang Retur</a></li> -->
      <!-- <li class="header">PEMASUKAN LAIN-LAIN</li>
      <li class="treeview <?php echo e((Request::segment(2) == 'other-transaction' ) ? 'active' : ''); ?>">
        <a href="#">
            <i class="fa fa-dollar"></i><span> Transaksi Lain</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
            <li class="<?php echo e(Request::segment(2) == 'other-transaction' && Request::segment(3) == 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/other-transaction/create')); ?>"><i class="fa fa-circle-o"></i> Tambah Transaksi Lain</a></li>
            <li class="<?php echo e(Request::segment(2) == 'other-transaction' && Request::segment(3) != 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/other-transaction/' . date('Y-m-d') . '/' . date('Y-m-d') . '/20')); ?>"><i class="fa fa-circle-o"></i> Daftar Transaksi Lain</a></li>
        </ul>
      </li> -->
      <?php if($role == 'admin'): ?>
        <!-- <li class="header">PENGELUARAN LAIN-LAIN</li>
        <li class="treeview <?php echo e((Request::segment(2) == 'other-payment' ) ? 'active' : ''); ?>">
          <a href="#">
              <i class="fa fa-plus"></i><span> Biaya Lain</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
              <li class="<?php echo e(Request::segment(2) == 'other-payment' && Request::segment(3) == 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/other-payment/create')); ?>"><i class="fa fa-circle-o"></i> Tambah Biaya Lain</a></li>
              <li class="<?php echo e(Request::segment(2) == 'other-payment' && Request::segment(3) != 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/other-payment/' . date('Y-m-d') . '/' . date('Y-m-d') . '/20')); ?>"><i class="fa fa-circle-o"></i> Daftar Biaya Lain</a></li>
          </ul>
        </li>
        <li class="treeview <?php echo e((Request::segment(2) == 'internal-transaction' ) ? 'active' : ''); ?>">
          <a href="#">
              <i class="fa fa-building-o"></i><span> Transaksi Internal</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
              <li class="<?php echo e(Request::segment(2) == 'internal-transaction' && Request::segment(3) == 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/internal-transaction/create')); ?>"><i class="fa fa-circle-o"></i> Tambah Transaksi Internal</a></li>
              <li class="<?php echo e(Request::segment(2) == 'internal-transaction' && Request::segment(3) != 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/internal-transaction/all/all/' . date('Y-m-d') . '/' . date('Y-m-d') . '/20')); ?>"><i class="fa fa-circle-o"></i> Daftar Transaksi Internal</a></li>
          </ul>
        </li> -->
        <li class="header">MENU LAIN</li>
        <!-- <li class="treeview <?php echo e((Request::segment(2) == 'brand' ) ? 'active' : ''); ?>">
          <a href="#">
              <i class="fa fa-html5"></i><span> Brand</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
              <li class="<?php echo e(Request::segment(2) == 'brand' && Request::segment(3) == 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/brand/create')); ?>"><i class="fa fa-circle-o"></i> Tambah Brand</a></li>
              <li class="<?php echo e(Request::segment(2) == 'brand' && Request::segment(3) != 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/brand/15')); ?>"><i class="fa fa-circle-o"></i> Daftar Brand</a></li>
          </ul>
        </li> -->
        <li class="treeview <?php echo e((Request::segment(2) == 'distributor' ) ? 'active' : ''); ?>">
          <a href="#">
              <i class="fa fa-truck"></i><span> Distributor</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
              <li class="<?php echo e(Request::segment(2) == 'distributor' && Request::segment(3) == 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/distributor/create')); ?>"><i class="fa fa-circle-o"></i> Tambah Distributor</a></li>
              <li class="<?php echo e(Request::segment(2) == 'distributor' && Request::segment(3) != 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/distributor/15')); ?>"><i class="fa fa-circle-o"></i> Daftar Distributor</a></li>
          </ul>
        </li>
        <li class="treeview <?php echo e((Request::segment(2) == 'category' ) ? 'active' : ''); ?>">
          <a href="#">
              <i class="fa fa-shopping-cart"></i><span> Kategori</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
              <li class="<?php echo e(Request::segment(2) == 'category' && Request::segment(3) == 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/category/create')); ?>"><i class="fa fa-circle-o"></i> Tambah Kategori</a></li>
              <li class="<?php echo e(Request::segment(2) == 'category' && Request::segment(3) != 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/category/15')); ?>"><i class="fa fa-circle-o"></i> Daftar Kategori</a></li>
          </ul>
        </li>
        <li class="treeview <?php echo e((Request::segment(2) == 'member' ) ? 'active' : ''); ?>">
          <a href="#">
              <i class="fa fa-users"></i><span> Member</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
              <li class="<?php echo e(Request::segment(2) == 'member' && Request::segment(3) == 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/member/create')); ?>"><i class="fa fa-circle-o"></i> Tambah Member</a></li>
              <li class="<?php echo e(Request::segment(2) == 'member' && Request::segment(3) != 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/member/15')); ?>"><i class="fa fa-circle-o"></i> Daftar Member</a></li>
          </ul>
        </li>
        <li class="treeview <?php echo e((Request::segment(2) == 'percentage' ) ? 'active' : ''); ?>">
          <a href="#">
              <i class="fa fa-percent"></i><span> Persentase</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
              <li class="<?php echo e(Request::segment(2) == 'percentage' && Request::segment(3) == 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/percentage/create')); ?>"><i class="fa fa-circle-o"></i> Tambah Persentase</a></li>
              <li class="<?php echo e(Request::segment(2) == 'percentage' && Request::segment(3) != 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/percentage/15')); ?>"><i class="fa fa-circle-o"></i> Daftar Persentase</a></li>
          </ul>
        </li>
        <!-- <li class="treeview <?php echo e(Request::segment(2) == 'unit' ? 'active' : ''); ?>">
          <a href="#">
            <i class="fa fa-shopping-basket"></i><span> Satuan</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
              <li class="<?php echo e(Request::segment(2) == 'unit' && Request::segment(3) == 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/unit/create')); ?>"><i class="fa fa-circle-o"></i> Tambah Satuan</a></li>
              <li class="<?php echo e(Request::segment(2) == 'unit' && Request::segment(3) != 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/unit/all')); ?>"><i class="fa fa-circle-o"></i> Daftar Satuan</a></li>
          </ul>
        </li> -->
      <?php endif; ?>
      <?php if(\Auth::user()->email == 'admin'): ?>
        <li class="header">LAPORAN KEUANGAN</li>
        <li class="treeview <?php echo e((Request::segment(2) == 'account' ) ? 'active' : ''); ?>">
          <a href="#">
              <i class="fa fa-book"></i><span> Akun</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
              <li class="<?php echo e(Request::segment(2) == 'account' && Request::segment(3) == 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/account/create')); ?>"><i class="fa fa-circle-o"></i> Tambah Akun</a></li>
              <li class="<?php echo e(Request::segment(2) == 'account' && Request::segment(3) != 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/account/15')); ?>"><i class="fa fa-circle-o"></i> Daftar Akun</a></li>
          </ul>
        </li>
        <li class="<?php echo e(Request::segment(2) == 'journal' && Request::segment(3) != 'create' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/journal/all/' . date('Y-m-d') . '/' . date('Y-m-d') . '/15')); ?>"><i class="fa fa-calculator"></i> Jurnal</a></li>
        <li class="<?php echo e(Request::segment(2) == 'profit' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/profit')); ?>"><i class="fa fa-arrow-circle-up"></i> Laba Rugi</a></li>
        <li class="<?php echo e(Request::segment(2) == 'scale' ? 'active' : ''); ?>"><a href="<?php echo e(url('/' . $role . '/scale')); ?>"><i class="fa fa-balance-scale"></i> Neraca</a></li>
      <?php endif; ?>
    </ul>
  </section>
</aside>
<?php /**PATH C:\project_caca\emas_pak_tani\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>