<div class="content-wrapper">

  <?php echo $__env->make('layout' . '.alert-message', ['type' => $default['type'], 'data' => $default['data'], 'color' => $default['color']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title">List Akun</h3>
            <?php echo $__env->make('layout.search-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
          <div class="box-body">
            <?php echo Form::label('show', 'Show', array('class' => 'col-sm-1 control-label')); ?>

           <div class="col-sm-1">
              <?php echo Form::select('show', getPaginations(), $pagination, ['class' => 'form-control', 'style'=>'width: 100%', 'id' => 'show', 'onchange' => 'advanceSearch()']); ?>

            </div>
          </div>
          <div class="box-body" style="overflow-x:scroll; color: black !important">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>Kode</th>
                <th>Nama</th>
                <th>Debet/Kredit</th>
                <th>Grup</th>
                <th>Saldo Awal</th>
                <th class="center">Detail</th>
                <th class="center">Ubah</th>
                <?php if($role == 'admin'): ?>
                  <th class="center">Hapus</th>
                <?php endif; ?>
              </tr>
              </thead>
              <tbody id="table-good">
                <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($account->code); ?></td>
                    <td><?php echo e($account->name); ?></td>
                    <td><?php echo e($account->type); ?></td>
                    <td><?php echo e($account->group); ?></td>
                    <td style="text-align: right;"><?php echo e(showRupiah($account->balance)); ?></td>
                    <td class="center"><a href="<?php echo e(url($role . '/account/' . $account->id . '/detail')); ?>"><i class="fa fa-hand-o-right tosca" aria-hidden="true"></i></a></td>
                    <td class="center"><a href="<?php echo e(url($role . '/account/' . $account->id . '/edit')); ?>"><i class="fa fa-file orange" aria-hidden="true"></i></a></td>
                    <?php if($role == 'admin'): ?>
                      <td class="center">
                        <button type="button" class="no-btn center" data-toggle="modal" data-target="#modal-danger-<?php echo e($account->id); ?>"><i class="fa fa-times" aria-hidden="true" style="color: red !important"></i></button>

                        <?php echo $__env->make('layout' . '.delete-modal', ['id' => $account->id, 'data' => $account->name, 'formName' => 'delete-form-' . $account->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <form id="delete-form-<?php echo e($account->id); ?>" action="<?php echo e(url($role . '/account/' . $account->id . '/delete')); ?>" method="POST" style="display: none;">
                          <?php echo e(csrf_field()); ?>

                          <?php echo e(method_field('DELETE')); ?>

                        </form>
                      </td>
                    <?php endif; ?>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <div id="renderField">
                <?php if($pagination != 'all'): ?>
                  <?php echo e($accounts->render()); ?>

                <?php endif; ?>
              </div>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<?php $__env->startSection('js-addon'); ?>
  <script type="text/javascript">
    $(document).ready(function(){
      
        $("#search-input").keyup( function(e){
          if(e.keyCode == 13)
          {
            ajaxFunction();
          }
        });

        $("#search-btn").click(function(){
            ajaxFunction();
        });
    });

    function advanceSearch()
    {
      var show        = $('#show').val();
      window.location = window.location.origin + '/<?php echo e($role); ?>/account/' + show;
    }
  </script>
<?php $__env->stopSection(); ?><?php /**PATH C:\project_caca\kuncen\resources\views/layout/account/all.blade.php ENDPATH**/ ?>