<div class="panel-body">
    <div class="row">
        <div class="col-sm-12">
            <div class="form-group">
                <div class="col-sm-8">
                    <input name="is_profile_picture" type="checkbox" value="1" checked="checked"> Jadikan gambar utama
                </div>
            </div>
        </div>

        <div class="col-sm-12">
            <div class="form-group">
                <?php echo Form::label('file', 'File', array('class' => 'col-sm-1 control-label')); ?>

                <div class="col-sm-3">
                    <?php echo Form::file('file', NULL, array('class' => 'form-control')); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php echo e(csrf_field()); ?>


<hr>
<?php if($SubmitButtonText == 'Edit'): ?>
    <?php echo Form::submit($SubmitButtonText, ['class' => 'btn btn-warning btn-flat btn-block form-control']); ?>

<?php elseif($SubmitButtonText == 'Tambah'): ?>
    <?php echo Form::submit($SubmitButtonText, ['class' => 'btn btn-success btn-flat btn-block form-control']); ?>

<?php elseif($SubmitButtonText == 'View'): ?>
<?php endif; ?>

<?php echo Form::close(); ?>


<?php $__env->startSection('js-addon'); ?>
<?php $__env->stopSection(); ?><?php /**PATH C:\project_caca\kuncen\resources\views/layout/good-photo/form.blade.php ENDPATH**/ ?>